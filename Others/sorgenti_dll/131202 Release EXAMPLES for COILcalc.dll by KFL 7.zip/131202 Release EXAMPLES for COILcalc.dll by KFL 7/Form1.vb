Public Class Form99
    Inherits System.Windows.Forms.Form

#Region " Codice generato da Progettazione Windows Form "

    Public Sub New()
        MyBase.New()

        'Chiamata richiesta da Progettazione Windows Form.
        InitializeComponent()

        'Aggiungere le eventuali istruzioni di inizializzazione dopo la chiamata a InitializeComponent()

    End Sub

    'Form esegue l'override del metodo Dispose per pulire l'elenco dei componenti.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Richiesto da Progettazione Windows Form
    Private components As System.ComponentModel.IContainer

    'NOTA: la procedura che segue � richiesta da Progettazione Windows Form.
    'Pu� essere modificata in Progettazione Windows Form.  
    'Non modificarla nell'editor del codice.
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox2 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox3 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox4 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox5 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox6 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox7 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox8 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox9 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox10 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox12 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox13 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox15 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox16 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox17 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox18 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox19 As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents TextBox100 As System.Windows.Forms.TextBox
    Friend WithEvents Label100 As System.Windows.Forms.Label
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents Label24 As System.Windows.Forms.Label
    Friend WithEvents Label25 As System.Windows.Forms.Label
    Friend WithEvents Label26 As System.Windows.Forms.Label
    Friend WithEvents Label27 As System.Windows.Forms.Label
    Friend WithEvents Label28 As System.Windows.Forms.Label
    Friend WithEvents Label29 As System.Windows.Forms.Label
    Friend WithEvents Label30 As System.Windows.Forms.Label
    Friend WithEvents TextBox21 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox22 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox23 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox24 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox25 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox26 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox27 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox28 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox29 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox30 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox31 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox32 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox33 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox34 As System.Windows.Forms.TextBox
    Friend WithEvents Label31 As System.Windows.Forms.Label
    Friend WithEvents Label32 As System.Windows.Forms.Label
    Friend WithEvents Label33 As System.Windows.Forms.Label
    Friend WithEvents Label34 As System.Windows.Forms.Label
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents Label51 As System.Windows.Forms.Label
    Friend WithEvents Label52 As System.Windows.Forms.Label
    Friend WithEvents Label53 As System.Windows.Forms.Label
    Friend WithEvents Label54 As System.Windows.Forms.Label
    Friend WithEvents Label55 As System.Windows.Forms.Label
    Friend WithEvents Label56 As System.Windows.Forms.Label
    Friend WithEvents Label57 As System.Windows.Forms.Label
    Friend WithEvents Label58 As System.Windows.Forms.Label
    Friend WithEvents Label59 As System.Windows.Forms.Label
    Friend WithEvents Label60 As System.Windows.Forms.Label
    Friend WithEvents Label61 As System.Windows.Forms.Label
    Friend WithEvents Label62 As System.Windows.Forms.Label
    Friend WithEvents Label63 As System.Windows.Forms.Label
    Friend WithEvents TextBox50 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox51 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox52 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox53 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox54 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox55 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox56 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox57 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox58 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox59 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox60 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox61 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox62 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox63 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox64 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox65 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox66 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox67 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox68 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox69 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox70 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox71 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox72 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox73 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox74 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox75 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox76 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox77 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox78 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox79 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox80 As System.Windows.Forms.TextBox
    Friend WithEvents Label64 As System.Windows.Forms.Label
    Friend WithEvents Label65 As System.Windows.Forms.Label
    Friend WithEvents Label66 As System.Windows.Forms.Label
    Friend WithEvents Label67 As System.Windows.Forms.Label
    Friend WithEvents Label68 As System.Windows.Forms.Label
    Friend WithEvents Label69 As System.Windows.Forms.Label
    Friend WithEvents Label70 As System.Windows.Forms.Label
    Friend WithEvents Label71 As System.Windows.Forms.Label
    Friend WithEvents Label72 As System.Windows.Forms.Label
    Friend WithEvents Label73 As System.Windows.Forms.Label
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents Button7 As System.Windows.Forms.Button
    Friend WithEvents TextBox40 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox35 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox36 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox37 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox38 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox41 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox42 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox43 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox44 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox45 As System.Windows.Forms.TextBox
    Friend WithEvents Label37 As System.Windows.Forms.Label
    Friend WithEvents Label39 As System.Windows.Forms.Label
    Friend WithEvents Label41 As System.Windows.Forms.Label
    Friend WithEvents Label42 As System.Windows.Forms.Label
    Friend WithEvents Label43 As System.Windows.Forms.Label
    Friend WithEvents TextBox39 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox46 As System.Windows.Forms.TextBox
    Friend WithEvents Label44 As System.Windows.Forms.Label
    Friend WithEvents Label45 As System.Windows.Forms.Label
    Friend WithEvents Label46 As System.Windows.Forms.Label
    Friend WithEvents Label47 As System.Windows.Forms.Label
    Friend WithEvents Label48 As System.Windows.Forms.Label
    Friend WithEvents Label49 As System.Windows.Forms.Label
    Friend WithEvents Label81 As System.Windows.Forms.Label
    Friend WithEvents Label85 As System.Windows.Forms.Label
    Friend WithEvents Label86 As System.Windows.Forms.Label
    Friend WithEvents Label87 As System.Windows.Forms.Label
    Friend WithEvents Label88 As System.Windows.Forms.Label
    Friend WithEvents Label89 As System.Windows.Forms.Label
    Friend WithEvents Label90 As System.Windows.Forms.Label
    Friend WithEvents Label91 As System.Windows.Forms.Label
    Friend WithEvents Label92 As System.Windows.Forms.Label
    Friend WithEvents Label93 As System.Windows.Forms.Label
    Friend WithEvents Label94 As System.Windows.Forms.Label
    Friend WithEvents Label95 As System.Windows.Forms.Label
    Friend WithEvents RichTextBox3 As System.Windows.Forms.RichTextBox
    Friend WithEvents Label38 As System.Windows.Forms.Label
    Friend WithEvents Label36 As System.Windows.Forms.Label
    Friend WithEvents Label35 As System.Windows.Forms.Label
    Friend WithEvents Label50 As System.Windows.Forms.Label
    Friend WithEvents Label40 As System.Windows.Forms.Label
    Friend WithEvents RichTextBox4 As System.Windows.Forms.RichTextBox
    Friend WithEvents Button3 As System.Windows.Forms.Button
    Friend WithEvents Button4 As System.Windows.Forms.Button
    Friend WithEvents Button5 As System.Windows.Forms.Button
    Friend WithEvents Label74 As System.Windows.Forms.Label
    Friend WithEvents Label75 As System.Windows.Forms.Label
    Friend WithEvents Label76 As System.Windows.Forms.Label
    Friend WithEvents Button11 As System.Windows.Forms.Button
    Friend WithEvents Button12 As System.Windows.Forms.Button
    Friend WithEvents Button13 As System.Windows.Forms.Button
    Friend WithEvents Button14 As System.Windows.Forms.Button
    Friend WithEvents Button15 As System.Windows.Forms.Button
    Friend WithEvents Button16 As System.Windows.Forms.Button
    Friend WithEvents Button17 As System.Windows.Forms.Button
    Friend WithEvents Button18 As System.Windows.Forms.Button
    Friend WithEvents Button19 As System.Windows.Forms.Button
    Friend WithEvents Button20 As System.Windows.Forms.Button
    Friend WithEvents Button21 As System.Windows.Forms.Button
    Friend WithEvents Button22 As System.Windows.Forms.Button
    Friend WithEvents Button23 As System.Windows.Forms.Button
    Friend WithEvents Button24 As System.Windows.Forms.Button
    Friend WithEvents Button25 As System.Windows.Forms.Button
    Friend WithEvents Button26 As System.Windows.Forms.Button
    Friend WithEvents Button27 As System.Windows.Forms.Button
    Friend WithEvents Button28 As System.Windows.Forms.Button
    Friend WithEvents TextBox11 As System.Windows.Forms.TextBox
    Friend WithEvents Label77 As System.Windows.Forms.Label
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(Form99))
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.TextBox2 = New System.Windows.Forms.TextBox()
        Me.TextBox3 = New System.Windows.Forms.TextBox()
        Me.TextBox4 = New System.Windows.Forms.TextBox()
        Me.TextBox5 = New System.Windows.Forms.TextBox()
        Me.TextBox6 = New System.Windows.Forms.TextBox()
        Me.TextBox7 = New System.Windows.Forms.TextBox()
        Me.TextBox8 = New System.Windows.Forms.TextBox()
        Me.TextBox9 = New System.Windows.Forms.TextBox()
        Me.TextBox10 = New System.Windows.Forms.TextBox()
        Me.TextBox12 = New System.Windows.Forms.TextBox()
        Me.TextBox13 = New System.Windows.Forms.TextBox()
        Me.TextBox15 = New System.Windows.Forms.TextBox()
        Me.TextBox16 = New System.Windows.Forms.TextBox()
        Me.TextBox17 = New System.Windows.Forms.TextBox()
        Me.TextBox18 = New System.Windows.Forms.TextBox()
        Me.TextBox19 = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.TextBox100 = New System.Windows.Forms.TextBox()
        Me.Label100 = New System.Windows.Forms.Label()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.Label28 = New System.Windows.Forms.Label()
        Me.Label29 = New System.Windows.Forms.Label()
        Me.Label30 = New System.Windows.Forms.Label()
        Me.TextBox21 = New System.Windows.Forms.TextBox()
        Me.TextBox22 = New System.Windows.Forms.TextBox()
        Me.TextBox23 = New System.Windows.Forms.TextBox()
        Me.TextBox24 = New System.Windows.Forms.TextBox()
        Me.TextBox25 = New System.Windows.Forms.TextBox()
        Me.TextBox26 = New System.Windows.Forms.TextBox()
        Me.TextBox27 = New System.Windows.Forms.TextBox()
        Me.TextBox28 = New System.Windows.Forms.TextBox()
        Me.TextBox29 = New System.Windows.Forms.TextBox()
        Me.TextBox30 = New System.Windows.Forms.TextBox()
        Me.TextBox31 = New System.Windows.Forms.TextBox()
        Me.TextBox32 = New System.Windows.Forms.TextBox()
        Me.TextBox33 = New System.Windows.Forms.TextBox()
        Me.TextBox34 = New System.Windows.Forms.TextBox()
        Me.Label31 = New System.Windows.Forms.Label()
        Me.Label32 = New System.Windows.Forms.Label()
        Me.Label33 = New System.Windows.Forms.Label()
        Me.Label34 = New System.Windows.Forms.Label()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Label51 = New System.Windows.Forms.Label()
        Me.Label52 = New System.Windows.Forms.Label()
        Me.Label53 = New System.Windows.Forms.Label()
        Me.Label54 = New System.Windows.Forms.Label()
        Me.Label55 = New System.Windows.Forms.Label()
        Me.Label56 = New System.Windows.Forms.Label()
        Me.Label57 = New System.Windows.Forms.Label()
        Me.Label58 = New System.Windows.Forms.Label()
        Me.Label59 = New System.Windows.Forms.Label()
        Me.Label60 = New System.Windows.Forms.Label()
        Me.Label61 = New System.Windows.Forms.Label()
        Me.Label62 = New System.Windows.Forms.Label()
        Me.Label63 = New System.Windows.Forms.Label()
        Me.TextBox50 = New System.Windows.Forms.TextBox()
        Me.TextBox51 = New System.Windows.Forms.TextBox()
        Me.TextBox52 = New System.Windows.Forms.TextBox()
        Me.TextBox53 = New System.Windows.Forms.TextBox()
        Me.TextBox54 = New System.Windows.Forms.TextBox()
        Me.TextBox55 = New System.Windows.Forms.TextBox()
        Me.TextBox56 = New System.Windows.Forms.TextBox()
        Me.TextBox57 = New System.Windows.Forms.TextBox()
        Me.TextBox58 = New System.Windows.Forms.TextBox()
        Me.TextBox59 = New System.Windows.Forms.TextBox()
        Me.TextBox60 = New System.Windows.Forms.TextBox()
        Me.TextBox61 = New System.Windows.Forms.TextBox()
        Me.TextBox62 = New System.Windows.Forms.TextBox()
        Me.TextBox63 = New System.Windows.Forms.TextBox()
        Me.TextBox64 = New System.Windows.Forms.TextBox()
        Me.TextBox65 = New System.Windows.Forms.TextBox()
        Me.TextBox66 = New System.Windows.Forms.TextBox()
        Me.TextBox67 = New System.Windows.Forms.TextBox()
        Me.TextBox68 = New System.Windows.Forms.TextBox()
        Me.TextBox69 = New System.Windows.Forms.TextBox()
        Me.TextBox70 = New System.Windows.Forms.TextBox()
        Me.TextBox71 = New System.Windows.Forms.TextBox()
        Me.TextBox72 = New System.Windows.Forms.TextBox()
        Me.TextBox73 = New System.Windows.Forms.TextBox()
        Me.TextBox74 = New System.Windows.Forms.TextBox()
        Me.TextBox75 = New System.Windows.Forms.TextBox()
        Me.TextBox76 = New System.Windows.Forms.TextBox()
        Me.TextBox77 = New System.Windows.Forms.TextBox()
        Me.TextBox78 = New System.Windows.Forms.TextBox()
        Me.TextBox79 = New System.Windows.Forms.TextBox()
        Me.TextBox80 = New System.Windows.Forms.TextBox()
        Me.Label64 = New System.Windows.Forms.Label()
        Me.Label65 = New System.Windows.Forms.Label()
        Me.Label66 = New System.Windows.Forms.Label()
        Me.Label67 = New System.Windows.Forms.Label()
        Me.Label68 = New System.Windows.Forms.Label()
        Me.Label69 = New System.Windows.Forms.Label()
        Me.Label70 = New System.Windows.Forms.Label()
        Me.Label71 = New System.Windows.Forms.Label()
        Me.Label72 = New System.Windows.Forms.Label()
        Me.Label73 = New System.Windows.Forms.Label()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button7 = New System.Windows.Forms.Button()
        Me.TextBox40 = New System.Windows.Forms.TextBox()
        Me.TextBox35 = New System.Windows.Forms.TextBox()
        Me.TextBox36 = New System.Windows.Forms.TextBox()
        Me.TextBox37 = New System.Windows.Forms.TextBox()
        Me.TextBox38 = New System.Windows.Forms.TextBox()
        Me.TextBox41 = New System.Windows.Forms.TextBox()
        Me.TextBox42 = New System.Windows.Forms.TextBox()
        Me.TextBox43 = New System.Windows.Forms.TextBox()
        Me.TextBox44 = New System.Windows.Forms.TextBox()
        Me.TextBox45 = New System.Windows.Forms.TextBox()
        Me.Label37 = New System.Windows.Forms.Label()
        Me.Label39 = New System.Windows.Forms.Label()
        Me.Label41 = New System.Windows.Forms.Label()
        Me.Label42 = New System.Windows.Forms.Label()
        Me.Label43 = New System.Windows.Forms.Label()
        Me.TextBox39 = New System.Windows.Forms.TextBox()
        Me.TextBox46 = New System.Windows.Forms.TextBox()
        Me.Label44 = New System.Windows.Forms.Label()
        Me.Label45 = New System.Windows.Forms.Label()
        Me.Label46 = New System.Windows.Forms.Label()
        Me.Label47 = New System.Windows.Forms.Label()
        Me.Label48 = New System.Windows.Forms.Label()
        Me.Label49 = New System.Windows.Forms.Label()
        Me.Label81 = New System.Windows.Forms.Label()
        Me.Label85 = New System.Windows.Forms.Label()
        Me.Label86 = New System.Windows.Forms.Label()
        Me.Label87 = New System.Windows.Forms.Label()
        Me.Label88 = New System.Windows.Forms.Label()
        Me.Label89 = New System.Windows.Forms.Label()
        Me.Label90 = New System.Windows.Forms.Label()
        Me.Label91 = New System.Windows.Forms.Label()
        Me.Label92 = New System.Windows.Forms.Label()
        Me.Label93 = New System.Windows.Forms.Label()
        Me.Label94 = New System.Windows.Forms.Label()
        Me.Label95 = New System.Windows.Forms.Label()
        Me.RichTextBox3 = New System.Windows.Forms.RichTextBox()
        Me.Label38 = New System.Windows.Forms.Label()
        Me.Label36 = New System.Windows.Forms.Label()
        Me.Label35 = New System.Windows.Forms.Label()
        Me.Label50 = New System.Windows.Forms.Label()
        Me.Label40 = New System.Windows.Forms.Label()
        Me.RichTextBox4 = New System.Windows.Forms.RichTextBox()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.Button5 = New System.Windows.Forms.Button()
        Me.Label74 = New System.Windows.Forms.Label()
        Me.Label75 = New System.Windows.Forms.Label()
        Me.Label76 = New System.Windows.Forms.Label()
        Me.Button11 = New System.Windows.Forms.Button()
        Me.Button12 = New System.Windows.Forms.Button()
        Me.Button13 = New System.Windows.Forms.Button()
        Me.Button14 = New System.Windows.Forms.Button()
        Me.Button15 = New System.Windows.Forms.Button()
        Me.Button16 = New System.Windows.Forms.Button()
        Me.Button17 = New System.Windows.Forms.Button()
        Me.Button18 = New System.Windows.Forms.Button()
        Me.Button19 = New System.Windows.Forms.Button()
        Me.Button20 = New System.Windows.Forms.Button()
        Me.Button21 = New System.Windows.Forms.Button()
        Me.Button22 = New System.Windows.Forms.Button()
        Me.Button23 = New System.Windows.Forms.Button()
        Me.Button24 = New System.Windows.Forms.Button()
        Me.Button25 = New System.Windows.Forms.Button()
        Me.Button26 = New System.Windows.Forms.Button()
        Me.Button27 = New System.Windows.Forms.Button()
        Me.Button28 = New System.Windows.Forms.Button()
        Me.TextBox11 = New System.Windows.Forms.TextBox()
        Me.Label77 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(440, 40)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(64, 20)
        Me.TextBox1.TabIndex = 1
        Me.TextBox1.Text = "22"
        '
        'TextBox2
        '
        Me.TextBox2.Location = New System.Drawing.Point(440, 56)
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.Size = New System.Drawing.Size(64, 20)
        Me.TextBox2.TabIndex = 2
        Me.TextBox2.Text = "21"
        '
        'TextBox3
        '
        Me.TextBox3.Location = New System.Drawing.Point(440, 72)
        Me.TextBox3.Name = "TextBox3"
        Me.TextBox3.Size = New System.Drawing.Size(64, 20)
        Me.TextBox3.TabIndex = 3
        Me.TextBox3.Text = "26"
        '
        'TextBox4
        '
        Me.TextBox4.BackColor = System.Drawing.SystemColors.Menu
        Me.TextBox4.Enabled = False
        Me.TextBox4.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox4.Location = New System.Drawing.Point(456, 88)
        Me.TextBox4.Name = "TextBox4"
        Me.TextBox4.Size = New System.Drawing.Size(48, 20)
        Me.TextBox4.TabIndex = 4
        Me.TextBox4.Text = "0"
        '
        'TextBox5
        '
        Me.TextBox5.Location = New System.Drawing.Point(440, 104)
        Me.TextBox5.Name = "TextBox5"
        Me.TextBox5.Size = New System.Drawing.Size(64, 20)
        Me.TextBox5.TabIndex = 5
        Me.TextBox5.Text = "31"
        '
        'TextBox6
        '
        Me.TextBox6.Location = New System.Drawing.Point(440, 120)
        Me.TextBox6.Name = "TextBox6"
        Me.TextBox6.Size = New System.Drawing.Size(64, 20)
        Me.TextBox6.TabIndex = 6
        Me.TextBox6.Text = "0"
        '
        'TextBox7
        '
        Me.TextBox7.Location = New System.Drawing.Point(440, 136)
        Me.TextBox7.Name = "TextBox7"
        Me.TextBox7.Size = New System.Drawing.Size(64, 20)
        Me.TextBox7.TabIndex = 7
        Me.TextBox7.Text = "1"
        '
        'TextBox8
        '
        Me.TextBox8.Location = New System.Drawing.Point(440, 152)
        Me.TextBox8.Name = "TextBox8"
        Me.TextBox8.Size = New System.Drawing.Size(64, 20)
        Me.TextBox8.TabIndex = 8
        Me.TextBox8.Text = "0"
        '
        'TextBox9
        '
        Me.TextBox9.Location = New System.Drawing.Point(440, 168)
        Me.TextBox9.Name = "TextBox9"
        Me.TextBox9.Size = New System.Drawing.Size(64, 20)
        Me.TextBox9.TabIndex = 9
        Me.TextBox9.Text = "2"
        '
        'TextBox10
        '
        Me.TextBox10.Location = New System.Drawing.Point(440, 184)
        Me.TextBox10.Name = "TextBox10"
        Me.TextBox10.Size = New System.Drawing.Size(64, 20)
        Me.TextBox10.TabIndex = 10
        Me.TextBox10.Text = "-1"
        '
        'TextBox12
        '
        Me.TextBox12.Location = New System.Drawing.Point(440, 216)
        Me.TextBox12.Name = "TextBox12"
        Me.TextBox12.Size = New System.Drawing.Size(64, 20)
        Me.TextBox12.TabIndex = 12
        Me.TextBox12.Text = "1"
        '
        'TextBox13
        '
        Me.TextBox13.Location = New System.Drawing.Point(440, 232)
        Me.TextBox13.Name = "TextBox13"
        Me.TextBox13.Size = New System.Drawing.Size(64, 20)
        Me.TextBox13.TabIndex = 13
        Me.TextBox13.Text = "0"
        '
        'TextBox15
        '
        Me.TextBox15.BackColor = System.Drawing.SystemColors.Menu
        Me.TextBox15.Enabled = False
        Me.TextBox15.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox15.Location = New System.Drawing.Point(456, 264)
        Me.TextBox15.Name = "TextBox15"
        Me.TextBox15.Size = New System.Drawing.Size(48, 20)
        Me.TextBox15.TabIndex = 15
        Me.TextBox15.Text = "0"
        '
        'TextBox16
        '
        Me.TextBox16.Location = New System.Drawing.Point(440, 280)
        Me.TextBox16.Name = "TextBox16"
        Me.TextBox16.Size = New System.Drawing.Size(64, 20)
        Me.TextBox16.TabIndex = 16
        Me.TextBox16.Text = "20000"
        '
        'TextBox17
        '
        Me.TextBox17.Location = New System.Drawing.Point(440, 296)
        Me.TextBox17.Name = "TextBox17"
        Me.TextBox17.Size = New System.Drawing.Size(64, 20)
        Me.TextBox17.TabIndex = 17
        Me.TextBox17.Text = "0"
        '
        'TextBox18
        '
        Me.TextBox18.Location = New System.Drawing.Point(440, 312)
        Me.TextBox18.Name = "TextBox18"
        Me.TextBox18.Size = New System.Drawing.Size(64, 20)
        Me.TextBox18.TabIndex = 18
        Me.TextBox18.Text = "0"
        '
        'TextBox19
        '
        Me.TextBox19.Location = New System.Drawing.Point(440, 328)
        Me.TextBox19.Name = "TextBox19"
        Me.TextBox19.Size = New System.Drawing.Size(64, 20)
        Me.TextBox19.TabIndex = 19
        Me.TextBox19.Text = "0"
        '
        'Label1
        '
        Me.Label1.Location = New System.Drawing.Point(512, 40)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(100, 16)
        Me.Label1.TabIndex = 20
        Me.Label1.Text = "Label1"
        '
        'Label2
        '
        Me.Label2.Location = New System.Drawing.Point(512, 56)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(100, 16)
        Me.Label2.TabIndex = 21
        Me.Label2.Text = "Label2"
        '
        'Label3
        '
        Me.Label3.Location = New System.Drawing.Point(512, 72)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(100, 16)
        Me.Label3.TabIndex = 22
        Me.Label3.Text = "Label3"
        '
        'Label4
        '
        Me.Label4.Location = New System.Drawing.Point(512, 88)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(100, 16)
        Me.Label4.TabIndex = 23
        Me.Label4.Text = "Label4"
        '
        'Label5
        '
        Me.Label5.Location = New System.Drawing.Point(512, 104)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(100, 16)
        Me.Label5.TabIndex = 24
        Me.Label5.Text = "Label5"
        '
        'Label6
        '
        Me.Label6.Location = New System.Drawing.Point(512, 120)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(100, 16)
        Me.Label6.TabIndex = 25
        Me.Label6.Text = "Label6"
        '
        'Label7
        '
        Me.Label7.Location = New System.Drawing.Point(512, 136)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(100, 16)
        Me.Label7.TabIndex = 26
        Me.Label7.Text = "Label7"
        '
        'Label8
        '
        Me.Label8.Location = New System.Drawing.Point(512, 152)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(100, 16)
        Me.Label8.TabIndex = 27
        Me.Label8.Text = "Label8"
        '
        'Label9
        '
        Me.Label9.Location = New System.Drawing.Point(512, 168)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(100, 16)
        Me.Label9.TabIndex = 28
        Me.Label9.Text = "Label9"
        '
        'Label10
        '
        Me.Label10.Location = New System.Drawing.Point(512, 184)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(100, 16)
        Me.Label10.TabIndex = 29
        Me.Label10.Text = "Label10"
        '
        'Label11
        '
        Me.Label11.Location = New System.Drawing.Point(512, 216)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(100, 16)
        Me.Label11.TabIndex = 30
        Me.Label11.Text = "Label11"
        '
        'Label12
        '
        Me.Label12.Location = New System.Drawing.Point(512, 232)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(100, 16)
        Me.Label12.TabIndex = 31
        Me.Label12.Text = "Label12"
        '
        'Label13
        '
        Me.Label13.Location = New System.Drawing.Point(512, 264)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(100, 16)
        Me.Label13.TabIndex = 32
        Me.Label13.Text = "Label13"
        '
        'Label14
        '
        Me.Label14.Location = New System.Drawing.Point(512, 280)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(100, 16)
        Me.Label14.TabIndex = 33
        Me.Label14.Text = "Label14"
        '
        'Label15
        '
        Me.Label15.Location = New System.Drawing.Point(512, 296)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(100, 16)
        Me.Label15.TabIndex = 34
        Me.Label15.Text = "Label15"
        '
        'Label16
        '
        Me.Label16.Location = New System.Drawing.Point(512, 312)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(100, 16)
        Me.Label16.TabIndex = 35
        Me.Label16.Text = "Label16"
        '
        'Label17
        '
        Me.Label17.Location = New System.Drawing.Point(512, 328)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(100, 16)
        Me.Label17.TabIndex = 36
        Me.Label17.Text = "Label17"
        '
        'Label18
        '
        Me.Label18.Location = New System.Drawing.Point(512, 360)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(100, 16)
        Me.Label18.TabIndex = 37
        Me.Label18.Text = "Label18"
        '
        'Label19
        '
        Me.Label19.Location = New System.Drawing.Point(512, 376)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(100, 16)
        Me.Label19.TabIndex = 38
        Me.Label19.Text = "Label19"
        '
        'Label20
        '
        Me.Label20.Location = New System.Drawing.Point(512, 392)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(100, 16)
        Me.Label20.TabIndex = 39
        Me.Label20.Text = "Label20"
        '
        'TextBox100
        '
        Me.TextBox100.Location = New System.Drawing.Point(440, 16)
        Me.TextBox100.Name = "TextBox100"
        Me.TextBox100.Size = New System.Drawing.Size(64, 20)
        Me.TextBox100.TabIndex = 0
        Me.TextBox100.Text = "1"
        '
        'Label100
        '
        Me.Label100.Location = New System.Drawing.Point(512, 16)
        Me.Label100.Name = "Label100"
        Me.Label100.Size = New System.Drawing.Size(100, 16)
        Me.Label100.TabIndex = 161
        Me.Label100.Text = "Label100"
        '
        'Label21
        '
        Me.Label21.Location = New System.Drawing.Point(512, 408)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(100, 16)
        Me.Label21.TabIndex = 171
        Me.Label21.Text = "Label21"
        '
        'Label22
        '
        Me.Label22.Location = New System.Drawing.Point(512, 424)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(100, 16)
        Me.Label22.TabIndex = 170
        Me.Label22.Text = "Label22"
        '
        'Label23
        '
        Me.Label23.Location = New System.Drawing.Point(512, 440)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(100, 16)
        Me.Label23.TabIndex = 169
        Me.Label23.Text = "Label23"
        '
        'Label24
        '
        Me.Label24.Location = New System.Drawing.Point(512, 456)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(100, 16)
        Me.Label24.TabIndex = 168
        Me.Label24.Text = "Label24"
        '
        'Label25
        '
        Me.Label25.Location = New System.Drawing.Point(512, 472)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(100, 16)
        Me.Label25.TabIndex = 167
        Me.Label25.Text = "Label25"
        '
        'Label26
        '
        Me.Label26.Location = New System.Drawing.Point(512, 488)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(100, 16)
        Me.Label26.TabIndex = 166
        Me.Label26.Text = "Label26"
        '
        'Label27
        '
        Me.Label27.Location = New System.Drawing.Point(512, 504)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(100, 16)
        Me.Label27.TabIndex = 165
        Me.Label27.Text = "Label27"
        '
        'Label28
        '
        Me.Label28.Location = New System.Drawing.Point(512, 520)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(100, 16)
        Me.Label28.TabIndex = 164
        Me.Label28.Text = "Label28"
        '
        'Label29
        '
        Me.Label29.Location = New System.Drawing.Point(512, 536)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(100, 16)
        Me.Label29.TabIndex = 163
        Me.Label29.Text = "Label29"
        '
        'Label30
        '
        Me.Label30.Location = New System.Drawing.Point(512, 552)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(100, 16)
        Me.Label30.TabIndex = 162
        Me.Label30.Text = "Label30"
        '
        'TextBox21
        '
        Me.TextBox21.Location = New System.Drawing.Point(440, 360)
        Me.TextBox21.Name = "TextBox21"
        Me.TextBox21.Size = New System.Drawing.Size(64, 20)
        Me.TextBox21.TabIndex = 21
        Me.TextBox21.Text = "2,5"
        '
        'TextBox22
        '
        Me.TextBox22.Location = New System.Drawing.Point(448, 376)
        Me.TextBox22.Name = "TextBox22"
        Me.TextBox22.Size = New System.Drawing.Size(56, 20)
        Me.TextBox22.TabIndex = 22
        Me.TextBox22.Text = "2,5"
        '
        'TextBox23
        '
        Me.TextBox23.Location = New System.Drawing.Point(440, 392)
        Me.TextBox23.Name = "TextBox23"
        Me.TextBox23.Size = New System.Drawing.Size(64, 20)
        Me.TextBox23.TabIndex = 23
        Me.TextBox23.Text = "0"
        '
        'TextBox24
        '
        Me.TextBox24.Location = New System.Drawing.Point(440, 408)
        Me.TextBox24.Name = "TextBox24"
        Me.TextBox24.Size = New System.Drawing.Size(64, 20)
        Me.TextBox24.TabIndex = 24
        Me.TextBox24.Text = "0,5"
        '
        'TextBox25
        '
        Me.TextBox25.Location = New System.Drawing.Point(432, 424)
        Me.TextBox25.Name = "TextBox25"
        Me.TextBox25.Size = New System.Drawing.Size(72, 20)
        Me.TextBox25.TabIndex = 25
        Me.TextBox25.Text = "35"
        '
        'TextBox26
        '
        Me.TextBox26.Location = New System.Drawing.Point(440, 440)
        Me.TextBox26.Name = "TextBox26"
        Me.TextBox26.Size = New System.Drawing.Size(64, 20)
        Me.TextBox26.TabIndex = 26
        Me.TextBox26.Text = "90"
        '
        'TextBox27
        '
        Me.TextBox27.Location = New System.Drawing.Point(440, 456)
        Me.TextBox27.Name = "TextBox27"
        Me.TextBox27.Size = New System.Drawing.Size(64, 20)
        Me.TextBox27.TabIndex = 27
        Me.TextBox27.Text = "70"
        '
        'TextBox28
        '
        Me.TextBox28.Location = New System.Drawing.Point(432, 472)
        Me.TextBox28.Name = "TextBox28"
        Me.TextBox28.Size = New System.Drawing.Size(72, 20)
        Me.TextBox28.TabIndex = 28
        Me.TextBox28.Text = "0"
        '
        'TextBox29
        '
        Me.TextBox29.Location = New System.Drawing.Point(432, 488)
        Me.TextBox29.Name = "TextBox29"
        Me.TextBox29.Size = New System.Drawing.Size(72, 20)
        Me.TextBox29.TabIndex = 29
        Me.TextBox29.Text = "0"
        '
        'TextBox30
        '
        Me.TextBox30.Location = New System.Drawing.Point(440, 504)
        Me.TextBox30.Name = "TextBox30"
        Me.TextBox30.Size = New System.Drawing.Size(64, 20)
        Me.TextBox30.TabIndex = 30
        Me.TextBox30.Text = "1000"
        '
        'TextBox31
        '
        Me.TextBox31.Location = New System.Drawing.Point(440, 520)
        Me.TextBox31.Name = "TextBox31"
        Me.TextBox31.Size = New System.Drawing.Size(64, 20)
        Me.TextBox31.TabIndex = 31
        Me.TextBox31.Text = "1000"
        '
        'TextBox32
        '
        Me.TextBox32.Location = New System.Drawing.Point(432, 536)
        Me.TextBox32.Name = "TextBox32"
        Me.TextBox32.Size = New System.Drawing.Size(72, 20)
        Me.TextBox32.TabIndex = 32
        Me.TextBox32.Text = "0"
        '
        'TextBox33
        '
        Me.TextBox33.Location = New System.Drawing.Point(432, 552)
        Me.TextBox33.Name = "TextBox33"
        Me.TextBox33.Size = New System.Drawing.Size(72, 20)
        Me.TextBox33.TabIndex = 33
        Me.TextBox33.Text = "0"
        '
        'TextBox34
        '
        Me.TextBox34.Location = New System.Drawing.Point(440, 568)
        Me.TextBox34.Name = "TextBox34"
        Me.TextBox34.Size = New System.Drawing.Size(64, 20)
        Me.TextBox34.TabIndex = 34
        Me.TextBox34.Text = "0"
        '
        'Label31
        '
        Me.Label31.Location = New System.Drawing.Point(512, 568)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(100, 16)
        Me.Label31.TabIndex = 186
        Me.Label31.Text = "Label31"
        '
        'Label32
        '
        Me.Label32.Location = New System.Drawing.Point(128, 104)
        Me.Label32.Name = "Label32"
        Me.Label32.Size = New System.Drawing.Size(100, 16)
        Me.Label32.TabIndex = 187
        Me.Label32.Text = "Label32"
        '
        'Label33
        '
        Me.Label33.Location = New System.Drawing.Point(128, 120)
        Me.Label33.Name = "Label33"
        Me.Label33.Size = New System.Drawing.Size(100, 16)
        Me.Label33.TabIndex = 188
        Me.Label33.Text = "Label33"
        '
        'Label34
        '
        Me.Label34.Location = New System.Drawing.Point(128, 136)
        Me.Label34.Name = "Label34"
        Me.Label34.Size = New System.Drawing.Size(100, 16)
        Me.Label34.TabIndex = 189
        Me.Label34.Text = "Label34"
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(8, 56)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(56, 23)
        Me.Button1.TabIndex = 190
        Me.Button1.Text = "Calc."
        '
        'Label51
        '
        Me.Label51.Location = New System.Drawing.Point(128, 408)
        Me.Label51.Name = "Label51"
        Me.Label51.Size = New System.Drawing.Size(100, 16)
        Me.Label51.TabIndex = 208
        Me.Label51.Text = "Label51"
        '
        'Label52
        '
        Me.Label52.Location = New System.Drawing.Point(128, 424)
        Me.Label52.Name = "Label52"
        Me.Label52.Size = New System.Drawing.Size(100, 16)
        Me.Label52.TabIndex = 209
        Me.Label52.Text = "Label52"
        '
        'Label53
        '
        Me.Label53.Location = New System.Drawing.Point(128, 440)
        Me.Label53.Name = "Label53"
        Me.Label53.Size = New System.Drawing.Size(100, 16)
        Me.Label53.TabIndex = 210
        Me.Label53.Text = "Label53"
        '
        'Label54
        '
        Me.Label54.Location = New System.Drawing.Point(128, 456)
        Me.Label54.Name = "Label54"
        Me.Label54.Size = New System.Drawing.Size(100, 16)
        Me.Label54.TabIndex = 211
        Me.Label54.Text = "Label54"
        '
        'Label55
        '
        Me.Label55.Location = New System.Drawing.Point(128, 472)
        Me.Label55.Name = "Label55"
        Me.Label55.Size = New System.Drawing.Size(100, 16)
        Me.Label55.TabIndex = 212
        Me.Label55.Text = "Label55"
        '
        'Label56
        '
        Me.Label56.Location = New System.Drawing.Point(128, 488)
        Me.Label56.Name = "Label56"
        Me.Label56.Size = New System.Drawing.Size(100, 16)
        Me.Label56.TabIndex = 213
        Me.Label56.Text = "Label56"
        '
        'Label57
        '
        Me.Label57.Location = New System.Drawing.Point(128, 504)
        Me.Label57.Name = "Label57"
        Me.Label57.Size = New System.Drawing.Size(100, 16)
        Me.Label57.TabIndex = 214
        Me.Label57.Text = "Label57"
        '
        'Label58
        '
        Me.Label58.Location = New System.Drawing.Point(128, 520)
        Me.Label58.Name = "Label58"
        Me.Label58.Size = New System.Drawing.Size(100, 16)
        Me.Label58.TabIndex = 215
        Me.Label58.Text = "Label58"
        '
        'Label59
        '
        Me.Label59.Location = New System.Drawing.Point(128, 536)
        Me.Label59.Name = "Label59"
        Me.Label59.Size = New System.Drawing.Size(100, 16)
        Me.Label59.TabIndex = 216
        Me.Label59.Text = "Label59"
        '
        'Label60
        '
        Me.Label60.Location = New System.Drawing.Point(592, 592)
        Me.Label60.Name = "Label60"
        Me.Label60.Size = New System.Drawing.Size(100, 16)
        Me.Label60.TabIndex = 217
        Me.Label60.Text = "Label60"
        '
        'Label61
        '
        Me.Label61.Location = New System.Drawing.Point(704, 592)
        Me.Label61.Name = "Label61"
        Me.Label61.Size = New System.Drawing.Size(100, 16)
        Me.Label61.TabIndex = 218
        Me.Label61.Text = "Label61"
        '
        'Label62
        '
        Me.Label62.Location = New System.Drawing.Point(128, 552)
        Me.Label62.Name = "Label62"
        Me.Label62.Size = New System.Drawing.Size(100, 16)
        Me.Label62.TabIndex = 219
        Me.Label62.Text = "Label62"
        '
        'Label63
        '
        Me.Label63.Location = New System.Drawing.Point(352, 8)
        Me.Label63.Name = "Label63"
        Me.Label63.Size = New System.Drawing.Size(48, 16)
        Me.Label63.TabIndex = 220
        Me.Label63.Text = "Label63"
        '
        'TextBox50
        '
        Me.TextBox50.Location = New System.Drawing.Point(8, 8)
        Me.TextBox50.Name = "TextBox50"
        Me.TextBox50.Size = New System.Drawing.Size(344, 20)
        Me.TextBox50.TabIndex = 236
        Me.TextBox50.Text = ""
        '
        'TextBox51
        '
        Me.TextBox51.Location = New System.Drawing.Point(0, 104)
        Me.TextBox51.Name = "TextBox51"
        Me.TextBox51.Size = New System.Drawing.Size(120, 20)
        Me.TextBox51.TabIndex = 237
        Me.TextBox51.Text = ""
        '
        'TextBox52
        '
        Me.TextBox52.Location = New System.Drawing.Point(0, 120)
        Me.TextBox52.Name = "TextBox52"
        Me.TextBox52.Size = New System.Drawing.Size(120, 20)
        Me.TextBox52.TabIndex = 238
        Me.TextBox52.Text = ""
        '
        'TextBox53
        '
        Me.TextBox53.Location = New System.Drawing.Point(0, 136)
        Me.TextBox53.Name = "TextBox53"
        Me.TextBox53.Size = New System.Drawing.Size(120, 20)
        Me.TextBox53.TabIndex = 239
        Me.TextBox53.Text = ""
        '
        'TextBox54
        '
        Me.TextBox54.Location = New System.Drawing.Point(0, 152)
        Me.TextBox54.Name = "TextBox54"
        Me.TextBox54.Size = New System.Drawing.Size(120, 20)
        Me.TextBox54.TabIndex = 240
        Me.TextBox54.Text = ""
        '
        'TextBox55
        '
        Me.TextBox55.Location = New System.Drawing.Point(0, 168)
        Me.TextBox55.Name = "TextBox55"
        Me.TextBox55.Size = New System.Drawing.Size(120, 20)
        Me.TextBox55.TabIndex = 241
        Me.TextBox55.Text = ""
        '
        'TextBox56
        '
        Me.TextBox56.Location = New System.Drawing.Point(0, 184)
        Me.TextBox56.Name = "TextBox56"
        Me.TextBox56.Size = New System.Drawing.Size(120, 20)
        Me.TextBox56.TabIndex = 242
        Me.TextBox56.Text = ""
        '
        'TextBox57
        '
        Me.TextBox57.Location = New System.Drawing.Point(0, 200)
        Me.TextBox57.Name = "TextBox57"
        Me.TextBox57.Size = New System.Drawing.Size(120, 20)
        Me.TextBox57.TabIndex = 243
        Me.TextBox57.Text = ""
        '
        'TextBox58
        '
        Me.TextBox58.Location = New System.Drawing.Point(0, 216)
        Me.TextBox58.Name = "TextBox58"
        Me.TextBox58.Size = New System.Drawing.Size(120, 20)
        Me.TextBox58.TabIndex = 244
        Me.TextBox58.Text = ""
        '
        'TextBox59
        '
        Me.TextBox59.Location = New System.Drawing.Point(0, 232)
        Me.TextBox59.Name = "TextBox59"
        Me.TextBox59.Size = New System.Drawing.Size(120, 20)
        Me.TextBox59.TabIndex = 245
        Me.TextBox59.Text = ""
        '
        'TextBox60
        '
        Me.TextBox60.Location = New System.Drawing.Point(0, 248)
        Me.TextBox60.Name = "TextBox60"
        Me.TextBox60.Size = New System.Drawing.Size(120, 20)
        Me.TextBox60.TabIndex = 246
        Me.TextBox60.Text = ""
        '
        'TextBox61
        '
        Me.TextBox61.Location = New System.Drawing.Point(0, 264)
        Me.TextBox61.Name = "TextBox61"
        Me.TextBox61.Size = New System.Drawing.Size(120, 20)
        Me.TextBox61.TabIndex = 247
        Me.TextBox61.Text = ""
        '
        'TextBox62
        '
        Me.TextBox62.Location = New System.Drawing.Point(0, 280)
        Me.TextBox62.Name = "TextBox62"
        Me.TextBox62.Size = New System.Drawing.Size(120, 20)
        Me.TextBox62.TabIndex = 248
        Me.TextBox62.Text = ""
        '
        'TextBox63
        '
        Me.TextBox63.Location = New System.Drawing.Point(0, 296)
        Me.TextBox63.Name = "TextBox63"
        Me.TextBox63.Size = New System.Drawing.Size(120, 20)
        Me.TextBox63.TabIndex = 249
        Me.TextBox63.Text = ""
        '
        'TextBox64
        '
        Me.TextBox64.Location = New System.Drawing.Point(0, 312)
        Me.TextBox64.Name = "TextBox64"
        Me.TextBox64.Size = New System.Drawing.Size(120, 20)
        Me.TextBox64.TabIndex = 250
        Me.TextBox64.Text = ""
        '
        'TextBox65
        '
        Me.TextBox65.Location = New System.Drawing.Point(0, 328)
        Me.TextBox65.Name = "TextBox65"
        Me.TextBox65.Size = New System.Drawing.Size(120, 20)
        Me.TextBox65.TabIndex = 251
        Me.TextBox65.Text = ""
        '
        'TextBox66
        '
        Me.TextBox66.Location = New System.Drawing.Point(0, 344)
        Me.TextBox66.Name = "TextBox66"
        Me.TextBox66.Size = New System.Drawing.Size(120, 20)
        Me.TextBox66.TabIndex = 252
        Me.TextBox66.Text = ""
        '
        'TextBox67
        '
        Me.TextBox67.Location = New System.Drawing.Point(0, 360)
        Me.TextBox67.Name = "TextBox67"
        Me.TextBox67.Size = New System.Drawing.Size(120, 20)
        Me.TextBox67.TabIndex = 253
        Me.TextBox67.Text = ""
        '
        'TextBox68
        '
        Me.TextBox68.Location = New System.Drawing.Point(0, 376)
        Me.TextBox68.Name = "TextBox68"
        Me.TextBox68.Size = New System.Drawing.Size(120, 20)
        Me.TextBox68.TabIndex = 254
        Me.TextBox68.Text = ""
        '
        'TextBox69
        '
        Me.TextBox69.Location = New System.Drawing.Point(0, 392)
        Me.TextBox69.Name = "TextBox69"
        Me.TextBox69.Size = New System.Drawing.Size(120, 20)
        Me.TextBox69.TabIndex = 255
        Me.TextBox69.Text = ""
        '
        'TextBox70
        '
        Me.TextBox70.Location = New System.Drawing.Point(0, 408)
        Me.TextBox70.Name = "TextBox70"
        Me.TextBox70.Size = New System.Drawing.Size(120, 20)
        Me.TextBox70.TabIndex = 256
        Me.TextBox70.Text = ""
        '
        'TextBox71
        '
        Me.TextBox71.Location = New System.Drawing.Point(0, 424)
        Me.TextBox71.Name = "TextBox71"
        Me.TextBox71.Size = New System.Drawing.Size(120, 20)
        Me.TextBox71.TabIndex = 257
        Me.TextBox71.Text = ""
        '
        'TextBox72
        '
        Me.TextBox72.Location = New System.Drawing.Point(0, 440)
        Me.TextBox72.Name = "TextBox72"
        Me.TextBox72.Size = New System.Drawing.Size(120, 20)
        Me.TextBox72.TabIndex = 258
        Me.TextBox72.Text = ""
        '
        'TextBox73
        '
        Me.TextBox73.Location = New System.Drawing.Point(0, 456)
        Me.TextBox73.Name = "TextBox73"
        Me.TextBox73.Size = New System.Drawing.Size(120, 20)
        Me.TextBox73.TabIndex = 259
        Me.TextBox73.Text = ""
        '
        'TextBox74
        '
        Me.TextBox74.Location = New System.Drawing.Point(0, 472)
        Me.TextBox74.Name = "TextBox74"
        Me.TextBox74.Size = New System.Drawing.Size(120, 20)
        Me.TextBox74.TabIndex = 260
        Me.TextBox74.Text = ""
        '
        'TextBox75
        '
        Me.TextBox75.Location = New System.Drawing.Point(0, 488)
        Me.TextBox75.Name = "TextBox75"
        Me.TextBox75.Size = New System.Drawing.Size(120, 20)
        Me.TextBox75.TabIndex = 261
        Me.TextBox75.Text = ""
        '
        'TextBox76
        '
        Me.TextBox76.Location = New System.Drawing.Point(0, 504)
        Me.TextBox76.Name = "TextBox76"
        Me.TextBox76.Size = New System.Drawing.Size(120, 20)
        Me.TextBox76.TabIndex = 262
        Me.TextBox76.Text = ""
        '
        'TextBox77
        '
        Me.TextBox77.Location = New System.Drawing.Point(0, 520)
        Me.TextBox77.Name = "TextBox77"
        Me.TextBox77.Size = New System.Drawing.Size(120, 20)
        Me.TextBox77.TabIndex = 263
        Me.TextBox77.Text = ""
        '
        'TextBox78
        '
        Me.TextBox78.Location = New System.Drawing.Point(0, 536)
        Me.TextBox78.Name = "TextBox78"
        Me.TextBox78.Size = New System.Drawing.Size(120, 20)
        Me.TextBox78.TabIndex = 264
        Me.TextBox78.Text = ""
        '
        'TextBox79
        '
        Me.TextBox79.Location = New System.Drawing.Point(0, 552)
        Me.TextBox79.Name = "TextBox79"
        Me.TextBox79.Size = New System.Drawing.Size(120, 20)
        Me.TextBox79.TabIndex = 265
        Me.TextBox79.Text = ""
        '
        'TextBox80
        '
        Me.TextBox80.Location = New System.Drawing.Point(0, 568)
        Me.TextBox80.Name = "TextBox80"
        Me.TextBox80.Size = New System.Drawing.Size(120, 20)
        Me.TextBox80.TabIndex = 266
        Me.TextBox80.Text = ""
        '
        'Label64
        '
        Me.Label64.Location = New System.Drawing.Point(168, 32)
        Me.Label64.Name = "Label64"
        Me.Label64.Size = New System.Drawing.Size(48, 16)
        Me.Label64.TabIndex = 267
        Me.Label64.Text = "Label64"
        '
        'Label65
        '
        Me.Label65.Location = New System.Drawing.Point(128, 568)
        Me.Label65.Name = "Label65"
        Me.Label65.Size = New System.Drawing.Size(100, 16)
        Me.Label65.TabIndex = 268
        Me.Label65.Text = "Label65"
        '
        'Label66
        '
        Me.Label66.Location = New System.Drawing.Point(336, 48)
        Me.Label66.Name = "Label66"
        Me.Label66.Size = New System.Drawing.Size(48, 16)
        Me.Label66.TabIndex = 269
        Me.Label66.Text = "Label66"
        '
        'Label67
        '
        Me.Label67.Location = New System.Drawing.Point(320, 80)
        Me.Label67.Name = "Label67"
        Me.Label67.Size = New System.Drawing.Size(48, 16)
        Me.Label67.TabIndex = 270
        Me.Label67.Text = "Label67"
        '
        'Label68
        '
        Me.Label68.Location = New System.Drawing.Point(208, 46)
        Me.Label68.Name = "Label68"
        Me.Label68.Size = New System.Drawing.Size(48, 16)
        Me.Label68.TabIndex = 271
        Me.Label68.Text = "Label68"
        '
        'Label69
        '
        Me.Label69.Location = New System.Drawing.Point(0, 592)
        Me.Label69.Name = "Label69"
        Me.Label69.Size = New System.Drawing.Size(100, 16)
        Me.Label69.TabIndex = 272
        Me.Label69.Text = "Label69"
        '
        'Label70
        '
        Me.Label70.Location = New System.Drawing.Point(112, 592)
        Me.Label70.Name = "Label70"
        Me.Label70.Size = New System.Drawing.Size(100, 16)
        Me.Label70.TabIndex = 273
        Me.Label70.Text = "Label70"
        '
        'Label71
        '
        Me.Label71.Location = New System.Drawing.Point(224, 592)
        Me.Label71.Name = "Label71"
        Me.Label71.Size = New System.Drawing.Size(100, 16)
        Me.Label71.TabIndex = 274
        Me.Label71.Text = "Label71"
        '
        'Label72
        '
        Me.Label72.Location = New System.Drawing.Point(336, 592)
        Me.Label72.Name = "Label72"
        Me.Label72.Size = New System.Drawing.Size(100, 16)
        Me.Label72.TabIndex = 275
        Me.Label72.Text = "Label72"
        '
        'Label73
        '
        Me.Label73.Location = New System.Drawing.Point(448, 592)
        Me.Label73.Name = "Label73"
        Me.Label73.Size = New System.Drawing.Size(100, 16)
        Me.Label73.TabIndex = 276
        Me.Label73.Text = "Label73"
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(72, 56)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(48, 23)
        Me.Button2.TabIndex = 285
        Me.Button2.Text = "Test_1"
        '
        'Button7
        '
        Me.Button7.Location = New System.Drawing.Point(8, 80)
        Me.Button7.Name = "Button7"
        Me.Button7.Size = New System.Drawing.Size(56, 23)
        Me.Button7.TabIndex = 291
        Me.Button7.Text = "Clear"
        '
        'TextBox40
        '
        Me.TextBox40.Location = New System.Drawing.Point(8, 32)
        Me.TextBox40.Name = "TextBox40"
        Me.TextBox40.Size = New System.Drawing.Size(160, 20)
        Me.TextBox40.TabIndex = 297
        Me.TextBox40.Text = ""
        '
        'TextBox35
        '
        Me.TextBox35.BackColor = System.Drawing.SystemColors.Menu
        Me.TextBox35.Enabled = False
        Me.TextBox35.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox35.Location = New System.Drawing.Point(320, 48)
        Me.TextBox35.Name = "TextBox35"
        Me.TextBox35.Size = New System.Drawing.Size(16, 20)
        Me.TextBox35.TabIndex = 344
        Me.TextBox35.Text = "0"
        '
        'TextBox36
        '
        Me.TextBox36.Location = New System.Drawing.Point(208, 72)
        Me.TextBox36.Name = "TextBox36"
        Me.TextBox36.Size = New System.Drawing.Size(104, 20)
        Me.TextBox36.TabIndex = 346
        Me.TextBox36.Text = "insert code"
        '
        'TextBox37
        '
        Me.TextBox37.Location = New System.Drawing.Point(176, 72)
        Me.TextBox37.Name = "TextBox37"
        Me.TextBox37.Size = New System.Drawing.Size(16, 20)
        Me.TextBox37.TabIndex = 348
        Me.TextBox37.Text = ""
        '
        'TextBox38
        '
        Me.TextBox38.Location = New System.Drawing.Point(176, 48)
        Me.TextBox38.Name = "TextBox38"
        Me.TextBox38.Size = New System.Drawing.Size(16, 20)
        Me.TextBox38.TabIndex = 349
        Me.TextBox38.Text = "0"
        '
        'TextBox41
        '
        Me.TextBox41.Location = New System.Drawing.Point(0, 608)
        Me.TextBox41.Name = "TextBox41"
        Me.TextBox41.TabIndex = 353
        Me.TextBox41.Text = ""
        '
        'TextBox42
        '
        Me.TextBox42.Location = New System.Drawing.Point(112, 608)
        Me.TextBox42.Name = "TextBox42"
        Me.TextBox42.TabIndex = 354
        Me.TextBox42.Text = "0"
        '
        'TextBox43
        '
        Me.TextBox43.Location = New System.Drawing.Point(224, 608)
        Me.TextBox43.Name = "TextBox43"
        Me.TextBox43.TabIndex = 355
        Me.TextBox43.Text = "0"
        '
        'TextBox44
        '
        Me.TextBox44.Location = New System.Drawing.Point(336, 608)
        Me.TextBox44.Name = "TextBox44"
        Me.TextBox44.TabIndex = 356
        Me.TextBox44.Text = "0"
        '
        'TextBox45
        '
        Me.TextBox45.Location = New System.Drawing.Point(448, 608)
        Me.TextBox45.Name = "TextBox45"
        Me.TextBox45.TabIndex = 357
        Me.TextBox45.Text = "0"
        '
        'Label37
        '
        Me.Label37.Location = New System.Drawing.Point(0, 632)
        Me.Label37.Name = "Label37"
        Me.Label37.Size = New System.Drawing.Size(104, 16)
        Me.Label37.TabIndex = 358
        Me.Label37.Text = "FLUID__NAME"
        '
        'Label39
        '
        Me.Label39.Location = New System.Drawing.Point(104, 632)
        Me.Label39.Name = "Label39"
        Me.Label39.Size = New System.Drawing.Size(112, 16)
        Me.Label39.TabIndex = 359
        Me.Label39.Text = "FLUID__SPECHEAD"
        '
        'Label41
        '
        Me.Label41.Location = New System.Drawing.Point(216, 632)
        Me.Label41.Name = "Label41"
        Me.Label41.Size = New System.Drawing.Size(128, 16)
        Me.Label41.TabIndex = 360
        Me.Label41.Text = "FLUID__SPECWEIGHT"
        '
        'Label42
        '
        Me.Label42.Location = New System.Drawing.Point(336, 632)
        Me.Label42.Name = "Label42"
        Me.Label42.Size = New System.Drawing.Size(112, 16)
        Me.Label42.TabIndex = 361
        Me.Label42.Text = "FLUID__VISCOSITY"
        '
        'Label43
        '
        Me.Label43.Location = New System.Drawing.Point(448, 632)
        Me.Label43.Name = "Label43"
        Me.Label43.Size = New System.Drawing.Size(136, 16)
        Me.Label43.TabIndex = 362
        Me.Label43.Text = "FLUID__CONDUCTIVITY"
        '
        'TextBox39
        '
        Me.TextBox39.Location = New System.Drawing.Point(592, 608)
        Me.TextBox39.Name = "TextBox39"
        Me.TextBox39.TabIndex = 363
        Me.TextBox39.Text = ""
        '
        'TextBox46
        '
        Me.TextBox46.Location = New System.Drawing.Point(704, 608)
        Me.TextBox46.Name = "TextBox46"
        Me.TextBox46.TabIndex = 364
        Me.TextBox46.Text = ""
        '
        'Label44
        '
        Me.Label44.Location = New System.Drawing.Point(584, 632)
        Me.Label44.Name = "Label44"
        Me.Label44.Size = New System.Drawing.Size(112, 16)
        Me.Label44.TabIndex = 365
        Me.Label44.Text = "_AIR_INLETWATER"
        '
        'Label45
        '
        Me.Label45.Location = New System.Drawing.Point(696, 632)
        Me.Label45.Name = "Label45"
        Me.Label45.Size = New System.Drawing.Size(128, 16)
        Me.Label45.TabIndex = 366
        Me.Label45.Text = "_AIR_OUTLETWATER"
        '
        'Label46
        '
        Me.Label46.Location = New System.Drawing.Point(128, 328)
        Me.Label46.Name = "Label46"
        Me.Label46.Size = New System.Drawing.Size(100, 16)
        Me.Label46.TabIndex = 367
        Me.Label46.Text = "Label46"
        '
        'Label47
        '
        Me.Label47.Location = New System.Drawing.Point(128, 344)
        Me.Label47.Name = "Label47"
        Me.Label47.Size = New System.Drawing.Size(100, 16)
        Me.Label47.TabIndex = 368
        Me.Label47.Text = "Label47"
        '
        'Label48
        '
        Me.Label48.Location = New System.Drawing.Point(128, 360)
        Me.Label48.Name = "Label48"
        Me.Label48.Size = New System.Drawing.Size(100, 16)
        Me.Label48.TabIndex = 369
        Me.Label48.Text = "Label48"
        '
        'Label49
        '
        Me.Label49.Location = New System.Drawing.Point(128, 376)
        Me.Label49.Name = "Label49"
        Me.Label49.Size = New System.Drawing.Size(100, 16)
        Me.Label49.TabIndex = 370
        Me.Label49.Text = "Label49"
        '
        'Label81
        '
        Me.Label81.Location = New System.Drawing.Point(128, 392)
        Me.Label81.Name = "Label81"
        Me.Label81.Size = New System.Drawing.Size(100, 16)
        Me.Label81.TabIndex = 371
        Me.Label81.Text = "Label50"
        '
        'Label85
        '
        Me.Label85.Location = New System.Drawing.Point(128, 152)
        Me.Label85.Name = "Label85"
        Me.Label85.Size = New System.Drawing.Size(100, 16)
        Me.Label85.TabIndex = 375
        Me.Label85.Text = "Label35"
        '
        'Label86
        '
        Me.Label86.Location = New System.Drawing.Point(128, 168)
        Me.Label86.Name = "Label86"
        Me.Label86.Size = New System.Drawing.Size(100, 16)
        Me.Label86.TabIndex = 376
        Me.Label86.Text = "Label36"
        '
        'Label87
        '
        Me.Label87.Location = New System.Drawing.Point(128, 184)
        Me.Label87.Name = "Label87"
        Me.Label87.Size = New System.Drawing.Size(100, 16)
        Me.Label87.TabIndex = 377
        Me.Label87.Text = "Label37"
        '
        'Label88
        '
        Me.Label88.Location = New System.Drawing.Point(128, 200)
        Me.Label88.Name = "Label88"
        Me.Label88.Size = New System.Drawing.Size(100, 16)
        Me.Label88.TabIndex = 378
        Me.Label88.Text = "Label38"
        '
        'Label89
        '
        Me.Label89.Location = New System.Drawing.Point(128, 216)
        Me.Label89.Name = "Label89"
        Me.Label89.Size = New System.Drawing.Size(100, 16)
        Me.Label89.TabIndex = 379
        Me.Label89.Text = "Label39"
        '
        'Label90
        '
        Me.Label90.Location = New System.Drawing.Point(128, 232)
        Me.Label90.Name = "Label90"
        Me.Label90.Size = New System.Drawing.Size(100, 16)
        Me.Label90.TabIndex = 380
        Me.Label90.Text = "Label40"
        '
        'Label91
        '
        Me.Label91.Location = New System.Drawing.Point(128, 248)
        Me.Label91.Name = "Label91"
        Me.Label91.Size = New System.Drawing.Size(100, 16)
        Me.Label91.TabIndex = 381
        Me.Label91.Text = "Label41"
        '
        'Label92
        '
        Me.Label92.Location = New System.Drawing.Point(128, 264)
        Me.Label92.Name = "Label92"
        Me.Label92.Size = New System.Drawing.Size(100, 16)
        Me.Label92.TabIndex = 382
        Me.Label92.Text = "Label42"
        '
        'Label93
        '
        Me.Label93.Location = New System.Drawing.Point(128, 280)
        Me.Label93.Name = "Label93"
        Me.Label93.Size = New System.Drawing.Size(100, 16)
        Me.Label93.TabIndex = 383
        Me.Label93.Text = "Label43"
        '
        'Label94
        '
        Me.Label94.Location = New System.Drawing.Point(128, 296)
        Me.Label94.Name = "Label94"
        Me.Label94.Size = New System.Drawing.Size(100, 16)
        Me.Label94.TabIndex = 384
        Me.Label94.Text = "Label44"
        '
        'Label95
        '
        Me.Label95.Location = New System.Drawing.Point(128, 312)
        Me.Label95.Name = "Label95"
        Me.Label95.Size = New System.Drawing.Size(100, 16)
        Me.Label95.TabIndex = 385
        Me.Label95.Text = "Label45"
        '
        'RichTextBox3
        '
        Me.RichTextBox3.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RichTextBox3.Location = New System.Drawing.Point(560, 8)
        Me.RichTextBox3.Name = "RichTextBox3"
        Me.RichTextBox3.Size = New System.Drawing.Size(264, 580)
        Me.RichTextBox3.TabIndex = 386
        Me.RichTextBox3.Text = "100" & Microsoft.VisualBasic.ChrW(9) & "COIL" & Microsoft.VisualBasic.ChrW(10) & Microsoft.VisualBasic.ChrW(10) & "1" & Microsoft.VisualBasic.ChrW(9) & "GEOMETRY" & Microsoft.VisualBasic.ChrW(10) & "2" & Microsoft.VisualBasic.ChrW(9) & "ROWSMAT" & Microsoft.VisualBasic.ChrW(10) & "3" & Microsoft.VisualBasic.ChrW(9) & "FINSPACING" & Microsoft.VisualBasic.ChrW(10) & "4" & Microsoft.VisualBasic.ChrW(9) & "FINSPACINGFREE" & Microsoft.VisualBasic.ChrW(10) & "5" & Microsoft.VisualBasic.ChrW(9) & "FINMAT" & Microsoft.VisualBasic.ChrW(10) & "6" & Microsoft.VisualBasic.ChrW(9) & "FINOPTION" & _
        "" & Microsoft.VisualBasic.ChrW(10) & "7" & Microsoft.VisualBasic.ChrW(9) & "FLUID_TYPE" & Microsoft.VisualBasic.ChrW(10) & "8" & Microsoft.VisualBasic.ChrW(9) & "FLUID_TYPE_TEC_   [ Tc ] [ Te ]" & Microsoft.VisualBasic.ChrW(10) & "9" & Microsoft.VisualBasic.ChrW(9) & "HEADERMAT_DE_     [ Devap ]" & Microsoft.VisualBasic.ChrW(10) & "10" & _
        "" & Microsoft.VisualBasic.ChrW(9) & "HEADERTYPE_DC_ -  [ Dcond ]" & Microsoft.VisualBasic.ChrW(10) & Microsoft.VisualBasic.ChrW(10) & Microsoft.VisualBasic.ChrW(10) & "11" & Microsoft.VisualBasic.ChrW(9) & "TYPEOFCIRCUITS" & Microsoft.VisualBasic.ChrW(10) & "12" & Microsoft.VisualBasic.ChrW(9) & "FREETUBES - ref" & Microsoft.VisualBasic.ChrW(10) & Microsoft.VisualBasic.ChrW(10) & "13" & Microsoft.VisualBasic.ChrW(9) & "FLUID_MA" & _
        "XPRESSUREWORK" & Microsoft.VisualBasic.ChrW(10) & "14" & Microsoft.VisualBasic.ChrW(9) & "AIR_MAXPRESSUREDROP" & Microsoft.VisualBasic.ChrW(10) & "15" & Microsoft.VisualBasic.ChrW(9) & "SEALEVEL" & Microsoft.VisualBasic.ChrW(10) & "16" & Microsoft.VisualBasic.ChrW(9) & "FOULINGFACTOR" & Microsoft.VisualBasic.ChrW(10) & "17" & Microsoft.VisualBasic.ChrW(9) & "SAFETYFACTO" & _
        "R" & Microsoft.VisualBasic.ChrW(10) & Microsoft.VisualBasic.ChrW(10) & Microsoft.VisualBasic.ChrW(10) & "18" & Microsoft.VisualBasic.ChrW(9) & "AIR_FLOWRATE ( * )" & Microsoft.VisualBasic.ChrW(10) & "19" & Microsoft.VisualBasic.ChrW(9) & "AIR_VELOCITY ( * )" & Microsoft.VisualBasic.ChrW(10) & "20" & Microsoft.VisualBasic.ChrW(9) & "AIR_INLETTEMP" & Microsoft.VisualBasic.ChrW(10) & "21" & Microsoft.VisualBasic.ChrW(9) & "AIR_HUMIDITY" & _
        "IN" & Microsoft.VisualBasic.ChrW(10) & "22" & Microsoft.VisualBasic.ChrW(9) & "AIR_OUTLETTEMP" & Microsoft.VisualBasic.ChrW(10) & "23" & Microsoft.VisualBasic.ChrW(9) & "FLUID_INLETTEMP_TS_    [ Ts ] [ dT ]" & Microsoft.VisualBasic.ChrW(10) & "24" & Microsoft.VisualBasic.ChrW(9) & "FLUID_OUTLETTEMP" & _
        "_TS_ [ Ts ] [ Ts ]" & Microsoft.VisualBasic.ChrW(10) & "25" & Microsoft.VisualBasic.ChrW(9) & "FLUID_FLOWRATE_TC_ * [ - ]   [ Tc ]" & Microsoft.VisualBasic.ChrW(10) & "26" & Microsoft.VisualBasic.ChrW(9) & "NOMINALCAPACITY *" & Microsoft.VisualBasic.ChrW(10) & "2" & _
        "7" & Microsoft.VisualBasic.ChrW(9) & "LENGHT" & Microsoft.VisualBasic.ChrW(10) & "28" & Microsoft.VisualBasic.ChrW(9) & "HEIGHT" & Microsoft.VisualBasic.ChrW(10) & "29" & Microsoft.VisualBasic.ChrW(9) & "NUMBEROFROWS  - ref *" & Microsoft.VisualBasic.ChrW(10) & "30" & Microsoft.VisualBasic.ChrW(9) & "NUMBEROFCIRCUITS  - ref *" & Microsoft.VisualBasic.ChrW(10) & "31" & Microsoft.VisualBasic.ChrW(9) & "HEAD" & _
        "ERCONF"
        '
        'Label38
        '
        Me.Label38.Location = New System.Drawing.Point(208, 58)
        Me.Label38.Name = "Label38"
        Me.Label38.Size = New System.Drawing.Size(64, 16)
        Me.Label38.TabIndex = 391
        Me.Label38.Text = "AIR__STD"
        '
        'Label36
        '
        Me.Label36.Location = New System.Drawing.Point(364, 80)
        Me.Label36.Name = "Label36"
        Me.Label36.Size = New System.Drawing.Size(72, 16)
        Me.Label36.TabIndex = 390
        Me.Label36.Text = "PASSWORD"
        '
        'Label35
        '
        Me.Label35.Location = New System.Drawing.Point(376, 48)
        Me.Label35.Name = "Label35"
        Me.Label35.Size = New System.Drawing.Size(64, 16)
        Me.Label35.TabIndex = 389
        Me.Label35.Text = "AUXILIARY"
        '
        'Label50
        '
        Me.Label50.Location = New System.Drawing.Point(392, 8)
        Me.Label50.Name = "Label50"
        Me.Label50.Size = New System.Drawing.Size(48, 16)
        Me.Label50.TabIndex = 387
        Me.Label50.Text = "_CODE"
        '
        'Label40
        '
        Me.Label40.Location = New System.Drawing.Point(208, 32)
        Me.Label40.Name = "Label40"
        Me.Label40.Size = New System.Drawing.Size(48, 16)
        Me.Label40.TabIndex = 388
        Me.Label40.Text = "_FLUID"
        '
        'RichTextBox4
        '
        Me.RichTextBox4.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RichTextBox4.Location = New System.Drawing.Point(176, 96)
        Me.RichTextBox4.Name = "RichTextBox4"
        Me.RichTextBox4.Size = New System.Drawing.Size(248, 492)
        Me.RichTextBox4.TabIndex = 392
        Me.RichTextBox4.Text = "32" & Microsoft.VisualBasic.ChrW(9) & "_AIR_FLOWRATE" & Microsoft.VisualBasic.ChrW(10) & "33" & Microsoft.VisualBasic.ChrW(9) & "_AIR_VELOCITY" & Microsoft.VisualBasic.ChrW(10) & "34" & Microsoft.VisualBasic.ChrW(9) & "_AIR_INLETTEMP" & Microsoft.VisualBasic.ChrW(10) & "35" & Microsoft.VisualBasic.ChrW(9) & "_AIR_HUMIDITYIN" & Microsoft.VisualBasic.ChrW(10) & "36" & Microsoft.VisualBasic.ChrW(9) & "_AIR_OU" & _
        "TLETTEMP" & Microsoft.VisualBasic.ChrW(10) & "37" & Microsoft.VisualBasic.ChrW(9) & "_AIR_HUMIDITYOUT" & Microsoft.VisualBasic.ChrW(10) & "38" & Microsoft.VisualBasic.ChrW(9) & "_AIR_PRESSUREDROP" & Microsoft.VisualBasic.ChrW(10) & "39" & Microsoft.VisualBasic.ChrW(9) & "_SHF " & Microsoft.VisualBasic.ChrW(10) & "40" & Microsoft.VisualBasic.ChrW(9) & "_AIR_CONDENSEDWATE" & _
        "R " & Microsoft.VisualBasic.ChrW(10) & "41" & Microsoft.VisualBasic.ChrW(9) & "_FLUID_INLETTEMP_TS_  [ T2 ]" & Microsoft.VisualBasic.ChrW(10) & "42" & Microsoft.VisualBasic.ChrW(9) & "_FLUID_OUTLETTEMP_TS_ [ T3 ]" & Microsoft.VisualBasic.ChrW(10) & "43" & Microsoft.VisualBasic.ChrW(9) & "_FLUID_FLO" & _
        "WRATE" & Microsoft.VisualBasic.ChrW(10) & "44" & Microsoft.VisualBasic.ChrW(9) & "_FLUID_VELOCITY_TEC_ [ T1 ]" & Microsoft.VisualBasic.ChrW(10) & "45" & Microsoft.VisualBasic.ChrW(9) & "_FLUID_PRESSUREDROP" & Microsoft.VisualBasic.ChrW(10) & "46" & Microsoft.VisualBasic.ChrW(9) & "_NOMINALCAPACITY" & Microsoft.VisualBasic.ChrW(10) & _
        "47" & Microsoft.VisualBasic.ChrW(9) & "_MAXCAPACITY" & Microsoft.VisualBasic.ChrW(10) & "48" & Microsoft.VisualBasic.ChrW(9) & "_LENGHT" & Microsoft.VisualBasic.ChrW(10) & "49" & Microsoft.VisualBasic.ChrW(9) & "_HEIGHT" & Microsoft.VisualBasic.ChrW(10) & "50" & Microsoft.VisualBasic.ChrW(9) & "_NUMBEROFROWS" & Microsoft.VisualBasic.ChrW(10) & "51" & Microsoft.VisualBasic.ChrW(9) & "_NUMBEROFCIRCUITS" & Microsoft.VisualBasic.ChrW(10) & Microsoft.VisualBasic.ChrW(10) & "52" & Microsoft.VisualBasic.ChrW(9) & _
        "_INTSURFACE" & Microsoft.VisualBasic.ChrW(10) & "53" & Microsoft.VisualBasic.ChrW(9) & "_EXTSURFACE" & Microsoft.VisualBasic.ChrW(10) & "54" & Microsoft.VisualBasic.ChrW(9) & "_VOLUME " & Microsoft.VisualBasic.ChrW(10) & "55" & Microsoft.VisualBasic.ChrW(9) & "_WEIGHT" & Microsoft.VisualBasic.ChrW(10) & "56" & Microsoft.VisualBasic.ChrW(9) & "_AIR_PRESSURE" & Microsoft.VisualBasic.ChrW(10) & "57" & Microsoft.VisualBasic.ChrW(9) & "_FLUID_HEA" & _
        "DERPRESSUREDR." & Microsoft.VisualBasic.ChrW(10) & "58" & Microsoft.VisualBasic.ChrW(9) & "_AIR_FLOWRATEKGS" & Microsoft.VisualBasic.ChrW(10) & "59" & Microsoft.VisualBasic.ChrW(9) & "_FLUID_FLOWRATEKGS" & Microsoft.VisualBasic.ChrW(10) & Microsoft.VisualBasic.ChrW(10) & "62" & Microsoft.VisualBasic.ChrW(9) & "_FLUID_INLETVAPORFR" & _
        "ACTION" & Microsoft.VisualBasic.ChrW(10) & "65" & Microsoft.VisualBasic.ChrW(9) & "_FLUID_PRESSURETEC "
        '
        'Button3
        '
        Me.Button3.Location = New System.Drawing.Point(120, 56)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(48, 23)
        Me.Button3.TabIndex = 393
        Me.Button3.Text = "Test_2"
        '
        'Button4
        '
        Me.Button4.Location = New System.Drawing.Point(72, 80)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(48, 23)
        Me.Button4.TabIndex = 394
        Me.Button4.Text = "Test_4"
        '
        'Button5
        '
        Me.Button5.Location = New System.Drawing.Point(120, 80)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(48, 23)
        Me.Button5.TabIndex = 395
        Me.Button5.Text = "Test_3"
        '
        'Label74
        '
        Me.Label74.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label74.Location = New System.Drawing.Point(192, 74)
        Me.Label74.Name = "Label74"
        Me.Label74.Size = New System.Drawing.Size(24, 16)
        Me.Label74.TabIndex = 396
        Me.Label74.Text = "<-"
        '
        'Label75
        '
        Me.Label75.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label75.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label75.Location = New System.Drawing.Point(768, 16)
        Me.Label75.Name = "Label75"
        Me.Label75.Size = New System.Drawing.Size(48, 16)
        Me.Label75.TabIndex = 399
        Me.Label75.Text = "INPUT"
        '
        'Label76
        '
        Me.Label76.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label76.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label76.Location = New System.Drawing.Point(360, 104)
        Me.Label76.Name = "Label76"
        Me.Label76.Size = New System.Drawing.Size(56, 16)
        Me.Label76.TabIndex = 400
        Me.Label76.Text = "OUTPUT"
        '
        'Button11
        '
        Me.Button11.Location = New System.Drawing.Point(0, 648)
        Me.Button11.Name = "Button11"
        Me.Button11.Size = New System.Drawing.Size(48, 23)
        Me.Button11.TabIndex = 406
        Me.Button11.Text = "EX 1.1"
        '
        'Button12
        '
        Me.Button12.Location = New System.Drawing.Point(48, 648)
        Me.Button12.Name = "Button12"
        Me.Button12.Size = New System.Drawing.Size(48, 23)
        Me.Button12.TabIndex = 407
        Me.Button12.Text = "EX 1.2"
        '
        'Button13
        '
        Me.Button13.Location = New System.Drawing.Point(96, 648)
        Me.Button13.Name = "Button13"
        Me.Button13.Size = New System.Drawing.Size(48, 23)
        Me.Button13.TabIndex = 408
        Me.Button13.Text = "EX 1.3"
        '
        'Button14
        '
        Me.Button14.Location = New System.Drawing.Point(144, 648)
        Me.Button14.Name = "Button14"
        Me.Button14.Size = New System.Drawing.Size(48, 23)
        Me.Button14.TabIndex = 409
        Me.Button14.Text = "EX 1.4"
        '
        'Button15
        '
        Me.Button15.Location = New System.Drawing.Point(192, 648)
        Me.Button15.Name = "Button15"
        Me.Button15.Size = New System.Drawing.Size(48, 23)
        Me.Button15.TabIndex = 410
        Me.Button15.Text = "EX 2.1"
        '
        'Button16
        '
        Me.Button16.Location = New System.Drawing.Point(240, 648)
        Me.Button16.Name = "Button16"
        Me.Button16.Size = New System.Drawing.Size(48, 23)
        Me.Button16.TabIndex = 411
        Me.Button16.Text = "EX 4.1"
        '
        'Button17
        '
        Me.Button17.Location = New System.Drawing.Point(288, 648)
        Me.Button17.Name = "Button17"
        Me.Button17.Size = New System.Drawing.Size(48, 23)
        Me.Button17.TabIndex = 412
        Me.Button17.Text = "EX 4.2"
        '
        'Button18
        '
        Me.Button18.Location = New System.Drawing.Point(336, 648)
        Me.Button18.Name = "Button18"
        Me.Button18.Size = New System.Drawing.Size(48, 23)
        Me.Button18.TabIndex = 413
        Me.Button18.Text = "EX 4.3"
        '
        'Button19
        '
        Me.Button19.Location = New System.Drawing.Point(384, 648)
        Me.Button19.Name = "Button19"
        Me.Button19.Size = New System.Drawing.Size(48, 23)
        Me.Button19.TabIndex = 414
        Me.Button19.Text = "EX 3.1"
        '
        'Button20
        '
        Me.Button20.Location = New System.Drawing.Point(432, 648)
        Me.Button20.Name = "Button20"
        Me.Button20.Size = New System.Drawing.Size(48, 23)
        Me.Button20.TabIndex = 415
        Me.Button20.Text = "EX 3.2"
        '
        'Button21
        '
        Me.Button21.Location = New System.Drawing.Point(480, 648)
        Me.Button21.Name = "Button21"
        Me.Button21.Size = New System.Drawing.Size(48, 23)
        Me.Button21.TabIndex = 416
        Me.Button21.Text = "EX 3.3"
        '
        'Button22
        '
        Me.Button22.Location = New System.Drawing.Point(536, 648)
        Me.Button22.Name = "Button22"
        Me.Button22.Size = New System.Drawing.Size(40, 23)
        Me.Button22.TabIndex = 417
        Me.Button22.Text = "EX 1"
        '
        'Button23
        '
        Me.Button23.Location = New System.Drawing.Point(576, 648)
        Me.Button23.Name = "Button23"
        Me.Button23.Size = New System.Drawing.Size(40, 23)
        Me.Button23.TabIndex = 418
        Me.Button23.Text = "EX 2"
        '
        'Button24
        '
        Me.Button24.Location = New System.Drawing.Point(616, 648)
        Me.Button24.Name = "Button24"
        Me.Button24.Size = New System.Drawing.Size(40, 23)
        Me.Button24.TabIndex = 419
        Me.Button24.Text = "EX 3"
        '
        'Button25
        '
        Me.Button25.Location = New System.Drawing.Point(656, 648)
        Me.Button25.Name = "Button25"
        Me.Button25.Size = New System.Drawing.Size(40, 23)
        Me.Button25.TabIndex = 420
        Me.Button25.Text = "EX 4"
        '
        'Button26
        '
        Me.Button26.Location = New System.Drawing.Point(696, 648)
        Me.Button26.Name = "Button26"
        Me.Button26.Size = New System.Drawing.Size(40, 23)
        Me.Button26.TabIndex = 421
        Me.Button26.Text = "EX 5"
        '
        'Button27
        '
        Me.Button27.Location = New System.Drawing.Point(736, 648)
        Me.Button27.Name = "Button27"
        Me.Button27.Size = New System.Drawing.Size(40, 23)
        Me.Button27.TabIndex = 422
        Me.Button27.Text = "EX 6"
        '
        'Button28
        '
        Me.Button28.Location = New System.Drawing.Point(776, 648)
        Me.Button28.Name = "Button28"
        Me.Button28.Size = New System.Drawing.Size(40, 23)
        Me.Button28.TabIndex = 423
        Me.Button28.Text = "EX 7"
        '
        'TextBox11
        '
        Me.TextBox11.Location = New System.Drawing.Point(288, 48)
        Me.TextBox11.Name = "TextBox11"
        Me.TextBox11.Size = New System.Drawing.Size(16, 20)
        Me.TextBox11.TabIndex = 424
        Me.TextBox11.Text = ""
        '
        'Label77
        '
        Me.Label77.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label77.Location = New System.Drawing.Point(304, 48)
        Me.Label77.Name = "Label77"
        Me.Label77.Size = New System.Drawing.Size(24, 16)
        Me.Label77.TabIndex = 425
        Me.Label77.Text = "<-"
        '
        'Form99
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(824, 678)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.TextBox36, Me.TextBox11, Me.Button28, Me.Button27, Me.Button26, Me.Button25, Me.Button24, Me.Button23, Me.Button22, Me.Button21, Me.Button20, Me.Button19, Me.Button18, Me.Button17, Me.Button16, Me.Button15, Me.Button14, Me.Button13, Me.Button12, Me.Button11, Me.Label76, Me.Label75, Me.Label36, Me.TextBox100, Me.TextBox35, Me.RichTextBox3, Me.Button5, Me.Button4, Me.Button3, Me.RichTextBox4, Me.Label38, Me.Label35, Me.Label50, Me.Label40, Me.Label66, Me.Label67, Me.Label45, Me.Label44, Me.TextBox46, Me.TextBox39, Me.Label43, Me.Label42, Me.Label41, Me.Label39, Me.Label37, Me.TextBox45, Me.TextBox44, Me.TextBox43, Me.TextBox42, Me.TextBox41, Me.TextBox38, Me.TextBox37, Me.TextBox40, Me.TextBox80, Me.TextBox79, Me.TextBox78, Me.TextBox77, Me.TextBox76, Me.Button7, Me.Button2, Me.Label73, Me.Label72, Me.Label71, Me.Label70, Me.Label69, Me.Label68, Me.Label64, Me.TextBox75, Me.TextBox74, Me.TextBox73, Me.TextBox72, Me.TextBox71, Me.TextBox70, Me.TextBox69, Me.TextBox68, Me.TextBox67, Me.TextBox66, Me.TextBox65, Me.TextBox64, Me.TextBox63, Me.TextBox62, Me.TextBox61, Me.TextBox60, Me.TextBox59, Me.TextBox58, Me.TextBox57, Me.TextBox56, Me.TextBox55, Me.TextBox54, Me.TextBox53, Me.TextBox52, Me.TextBox51, Me.TextBox50, Me.Label63, Me.Label61, Me.Label60, Me.Button1, Me.TextBox34, Me.TextBox33, Me.TextBox32, Me.TextBox31, Me.TextBox30, Me.TextBox29, Me.TextBox28, Me.TextBox27, Me.TextBox26, Me.TextBox25, Me.TextBox24, Me.TextBox23, Me.TextBox22, Me.TextBox21, Me.TextBox19, Me.TextBox18, Me.TextBox17, Me.TextBox16, Me.TextBox15, Me.TextBox13, Me.TextBox12, Me.TextBox10, Me.TextBox9, Me.TextBox8, Me.TextBox7, Me.TextBox6, Me.TextBox5, Me.TextBox4, Me.TextBox3, Me.TextBox2, Me.TextBox1, Me.Label21, Me.Label22, Me.Label23, Me.Label24, Me.Label25, Me.Label26, Me.Label27, Me.Label28, Me.Label29, Me.Label30, Me.Label20, Me.Label19, Me.Label18, Me.Label17, Me.Label16, Me.Label15, Me.Label14, Me.Label13, Me.Label12, Me.Label11, Me.Label10, Me.Label9, Me.Label8, Me.Label7, Me.Label6, Me.Label5, Me.Label4, Me.Label100, Me.Label3, Me.Label2, Me.Label1, Me.Label31, Me.Label32, Me.Label33, Me.Label95, Me.Label94, Me.Label93, Me.Label92, Me.Label91, Me.Label90, Me.Label89, Me.Label88, Me.Label87, Me.Label86, Me.Label85, Me.Label81, Me.Label49, Me.Label48, Me.Label47, Me.Label46, Me.Label51, Me.Label34, Me.Label59, Me.Label58, Me.Label57, Me.Label56, Me.Label55, Me.Label54, Me.Label53, Me.Label52, Me.Label65, Me.Label62, Me.Label74, Me.Label77})
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "Form99"
        Me.Text = "   EXAMPLES  for  COILcalc.dll  by  KFL"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Structure COILcalcStructure

        'input
        Dim COIL As Integer
        Dim GEOMETRY As Integer
        Dim ROWSMAT As Integer
        Dim FINSPACING As Integer
        Dim FINSPACINGFREE As Double
        Dim FINMAT As Integer
        Dim FINOPTION As Integer
        Dim FLUID_TYPE As Integer
        Dim FLUID_TYPE_TEC_ As Double
        Dim HEADERMAT_DE_ As Integer
        Dim HEADERTYPE_DC_ As Integer
        Dim TYPEOFCIRCUITS As Integer
        Dim FREETUBES As Double
        Dim FLUID_MAXPRESSUREWORK As Integer
        Dim FLUID_MAXPRESSUREDROP As Double
        Dim SEALEVEL As Double
        Dim FOULINGFACTOR As Double
        Dim SAFETYFACTOR As Double
        Dim AIR_FLOWRATE As Double
        Dim AIR_VELOCITY As Double
        Dim AIR_INLETTEMP As Double
        Dim AIR_HUMIDITYIN As Double
        Dim AIR_OUTLETTEMP As Double
        Dim FLUID_INLETTEMP_TS_ As Double
        Dim FLUID_OUTLETTEMP_TS_ As Double
        Dim FLUID_FLOWRATE_TC_ As Double
        Dim NOMINALCAPACITY As Double
        Dim LENGHT As Double
        Dim HEIGHT As Double
        Dim NUMBEROFROWS As Double
        Dim NUMBEROFCIRCUITS As Double
        Dim HEADERCONF As Integer

        'output
        Dim _AIR_FLOWRATE As Double
        Dim _AIR_VELOCITY As Double
        Dim _AIR_INLETTEMP As Double
        Dim _AIR_HUMIDITYIN As Double
        Dim _AIR_OUTLETTEMP As Double
        Dim _AIR_HUMIDITYOUT As Double
        Dim _AIR_PRESSUREDROP As Double
        Dim _SHF As Double
        Dim _AIR_CONDENSEDWATER As Double
        Dim _FLUID_INLETTEMP_TS As Double
        Dim _FLUID_OUTLETTEMP_TS As Double
        Dim _FLUID_FLOWRATE As Double
        Dim _FLUID_VELOCITY_TEC_ As Double
        Dim _FLUID_PRESSUREDROP As Double
        Dim _NOMINALCAPACITY As Double
        Dim _MAXCAPACITY As Double
        Dim _LENGHT As Double
        Dim _HEIGHT As Double
        Dim _NUMBEROFROWS As Double
        Dim _NUMBEROFCIRCUITS As Double
        Dim _INTSURFACE As Double
        Dim _EXTSURFACE As Double
        Dim _VOLUME As Double
        Dim _WEIGHT As Double
        Dim _AIR_PRESSURE As Double
        Dim _FLUID_HEADERPRESSUREDROP As Double
        Dim _AIR_FLOWRATEKGS As Double
        Dim _FLUID_FLOWRATEKGS As Double
        Dim _AIR_INLETWATER As Double
        Dim _AIR_OUTLETWATER As Double
        Dim _FLUID_INLETVAPORFRACTION As Double
        Dim _CODE As String
        Dim _FLUID As String
        Dim _FLUID_PRESSURETEC As Double

        'others
        Dim AUXILIARY As Double
        Dim PASSWORD As String
        Dim AIR__STD As Double
        Dim FLUID__NAME As String
        Dim FLUID__SPECHEAD As Double
        Dim FLUID__SPECWEIGHT As Double
        Dim FLUID__VISCOSITY As Double
        Dim FLUID__CONDUCTIVITY As Double

    End Structure


    Public Declare Function COILcalc Lib "COILcalc" (ByRef X As COILcalcStructure) As Long


    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click

        calc()

    End Sub

    Sub calc()

        '****** INPUT ******

        Dim Pippo As New COILcalcStructure()

        With Pippo
            .COIL = TextBox100.Text
            .GEOMETRY = TextBox1.Text
            .ROWSMAT = TextBox2.Text
            .FINSPACING = TextBox3.Text
            .FINSPACINGFREE = 0           'NOT USED   TextBox4.Text
            .FINMAT = TextBox5.Text
            .FINOPTION = TextBox6.Text
            .FLUID_TYPE = TextBox7.Text
            .FLUID_TYPE_TEC_ = TextBox8.Text
            .HEADERMAT_DE_ = TextBox9.Text
            .HEADERTYPE_DC_ = TextBox10.Text
            'NOT USED           TextBox11.Text
            .TYPEOFCIRCUITS = TextBox12.Text
            .FREETUBES = TextBox13.Text
            'NOT USED           TextBox14.Text
            .FLUID_MAXPRESSUREWORK = 0    'NOT USED   TextBox15.Text
            .FLUID_MAXPRESSUREDROP = TextBox16.Text
            .SEALEVEL = TextBox17.Text
            .FOULINGFACTOR = TextBox18.Text
            .SAFETYFACTOR = TextBox19.Text
            'NOT USED           TextBox20.Text
            .AIR_FLOWRATE = TextBox21.Text
            .AIR_VELOCITY = TextBox22.Text
            .AIR_INLETTEMP = TextBox23.Text
            .AIR_HUMIDITYIN = TextBox24.Text
            .AIR_OUTLETTEMP = TextBox25.Text
            .FLUID_INLETTEMP_TS_ = TextBox26.Text
            .FLUID_OUTLETTEMP_TS_ = TextBox27.Text
            .FLUID_FLOWRATE_TC_ = TextBox28.Text
            .NOMINALCAPACITY = TextBox29.Text
            .LENGHT = TextBox30.Text
            .HEIGHT = TextBox31.Text
            .NUMBEROFROWS = TextBox32.Text
            .NUMBEROFCIRCUITS = TextBox33.Text
            .HEADERCONF = TextBox34.Text

            .AUXILIARY = 0    'NOT USED   TextBox35.Text
            .PASSWORD = TextBox36.Text
            .AIR__STD = TextBox38.Text

            .FLUID__NAME = TextBox41.Text
            .FLUID__SPECHEAD = TextBox42.Text
            .FLUID__SPECWEIGHT = TextBox43.Text
            .FLUID__VISCOSITY = TextBox44.Text
            .FLUID__CONDUCTIVITY = TextBox45.Text

        End With

        '****** CALL DLL ******

        COILcalc(Pippo)

        '****** OUTPUT ******

        With Pippo
            TextBox40.Text = ._FLUID
            TextBox50.Text = ._CODE
            TextBox80.Text = CDbl(String.Format("{0:F2}", ._FLUID_PRESSURETEC))

            TextBox51.Text = CDbl(String.Format("{0:F2}", ._AIR_FLOWRATE))
            TextBox52.Text = CDbl(String.Format("{0:F2}", ._AIR_VELOCITY))
            TextBox53.Text = CDbl(String.Format("{0:F2}", ._AIR_INLETTEMP))

            ._AIR_HUMIDITYIN = ._AIR_HUMIDITYIN * 100
            TextBox54.Text = CDbl(String.Format("{0:F2}", ._AIR_HUMIDITYIN))
            TextBox55.Text = CDbl(String.Format("{0:F2}", ._AIR_OUTLETTEMP))

            ._AIR_HUMIDITYOUT = ._AIR_HUMIDITYOUT * 100
            TextBox56.Text = CDbl(String.Format("{0:F2}", ._AIR_HUMIDITYOUT))
            TextBox57.Text = CDbl(String.Format("{0:F2}", ._AIR_PRESSUREDROP))
            TextBox58.Text = CDbl(String.Format("{0:F2}", ._SHF))

            ._AIR_CONDENSEDWATER = ._AIR_CONDENSEDWATER * 10 ^ 3    'g/s
            TextBox59.Text = CDbl(String.Format("{0:F2}", ._AIR_CONDENSEDWATER))
            TextBox60.Text = CDbl(String.Format("{0:F2}", ._FLUID_INLETTEMP_TS))
            TextBox61.Text = CDbl(String.Format("{0:F2}", ._FLUID_OUTLETTEMP_TS))

            ._FLUID_FLOWRATE = ._FLUID_FLOWRATE * 10 ^ 3
            TextBox62.Text = CDbl(String.Format("{0:F2}", ._FLUID_FLOWRATE))
            TextBox63.Text = CDbl(String.Format("{0:F2}", ._FLUID_VELOCITY_TEC_))

            ._FLUID_PRESSUREDROP = ._FLUID_PRESSUREDROP * 10 ^ -3
            TextBox64.Text = CDbl(String.Format("{0:F2}", ._FLUID_PRESSUREDROP))
            ._NOMINALCAPACITY = ._NOMINALCAPACITY * 10 ^ -3
            TextBox65.Text = CDbl(String.Format("{0:F2}", ._NOMINALCAPACITY))

            If ._MAXCAPACITY = 0 Then
                ._NOMINALCAPACITY = ._NOMINALCAPACITY * 10 ^ 3
                ._MAXCAPACITY = ._NOMINALCAPACITY
            End If
            ._MAXCAPACITY = ._MAXCAPACITY * 10 ^ -3
            TextBox66.Text = CDbl(String.Format("{0:F2}", ._MAXCAPACITY))

            ._LENGHT = ._LENGHT * 10 ^ 3
            TextBox67.Text = CDbl(String.Format("{0:F2}", ._LENGHT))
            ._HEIGHT = ._HEIGHT * 10 ^ 3
            TextBox68.Text = CDbl(String.Format("{0:F2}", ._HEIGHT))

            TextBox69.Text = CDbl(String.Format("{0:F2}", ._NUMBEROFROWS))
            TextBox70.Text = CDbl(String.Format("{0:F2}", ._NUMBEROFCIRCUITS))
            TextBox71.Text = CDbl(String.Format("{0:F2}", ._INTSURFACE))
            TextBox72.Text = CDbl(String.Format("{0:F2}", ._EXTSURFACE))
            TextBox73.Text = CDbl(String.Format("{0:F2}", ._VOLUME))
            TextBox74.Text = CDbl(String.Format("{0:F2}", ._WEIGHT))

            ._AIR_PRESSURE = ._AIR_PRESSURE * 10 ^ -3
            TextBox75.Text = CDbl(String.Format("{0:F2}", ._AIR_PRESSURE))
            ._FLUID_HEADERPRESSUREDROP = ._FLUID_HEADERPRESSUREDROP * 10 ^ -3
            TextBox76.Text = CDbl(String.Format("{0:F2}", ._FLUID_HEADERPRESSUREDROP))

            TextBox77.Text = CDbl(String.Format("{0:F2}", ._AIR_FLOWRATEKGS))
            TextBox78.Text = CDbl(String.Format("{0:F2}", ._FLUID_FLOWRATEKGS))
            TextBox79.Text = CDbl(String.Format("{0:F2}", ._FLUID_INLETVAPORFRACTION))

            TextBox11.Text = .AUXILIARY

            TextBox37.Text = .PASSWORD

            TextBox41.Text = .FLUID__NAME
            TextBox42.Text = .FLUID__SPECHEAD
            TextBox43.Text = .FLUID__SPECWEIGHT
            TextBox44.Text = .FLUID__VISCOSITY
            TextBox45.Text = .FLUID__CONDUCTIVITY

            TextBox39.Text = ._AIR_INLETWATER
            TextBox46.Text = ._AIR_OUTLETWATER

        End With

    End Sub


    '****** DECLARATION ******

    '****** FACILITIES ******

    Private Sub Button7_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button7.Click

        Clear__DLL()

    End Sub

    Private Sub Clear__DLL()

        'Clear
        TextBox38.Text = 0

        TextBox40.Clear()
        TextBox50.Clear()

        TextBox51.Clear()
        TextBox52.Clear()
        TextBox53.Clear()
        TextBox54.Clear()
        TextBox55.Clear()
        TextBox56.Clear()
        TextBox57.Clear()
        TextBox58.Clear()
        TextBox59.Clear()
        TextBox60.Clear()
        TextBox61.Clear()
        TextBox62.Clear()
        TextBox63.Clear()
        TextBox64.Clear()
        TextBox65.Clear()
        TextBox66.Clear()
        TextBox67.Clear()
        TextBox68.Clear()
        TextBox69.Clear()
        TextBox70.Clear()
        TextBox71.Clear()
        TextBox72.Clear()
        TextBox73.Clear()
        TextBox74.Clear()
        TextBox75.Clear()
        TextBox76.Clear()
        TextBox77.Clear()
        TextBox78.Clear()
        TextBox79.Clear()
        TextBox80.Clear()

        TextBox41.Clear()
        TextBox42.Text = 0
        TextBox43.Text = 0
        TextBox44.Text = 0
        TextBox45.Text = 0
        TextBox39.Clear()
        TextBox46.Clear()
        'FINE Clear

    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click

        Test__DLL_1()

    End Sub
    Private Sub Test__DLL_1()

        TextBox100.Text = 1
        TextBox1.Text = 22
        TextBox2.Text = 21
        TextBox3.Text = 26
        TextBox4.Text = 0
        TextBox5.Text = 31
        TextBox6.Text = 0
        TextBox7.Text = 1
        TextBox8.Text = 0
        TextBox9.Text = 2
        TextBox10.Text = -1

        TextBox12.Text = 1
        TextBox13.Text = 0

        TextBox15.Text = 0
        TextBox16.Text = 20000
        TextBox17.Text = 0
        TextBox18.Text = 0
        TextBox19.Text = 0

        TextBox21.Text = 2.5
        TextBox22.Text = 2.5
        TextBox23.Text = 0
        TextBox24.Text = 0.5
        TextBox25.Text = 35
        TextBox26.Text = 90
        TextBox27.Text = 70
        TextBox28.Text = 0
        TextBox29.Text = 0
        TextBox30.Text = 1000
        TextBox31.Text = 1000
        TextBox32.Text = 0
        TextBox33.Text = 0
        TextBox34.Text = 0


        TextBox38.Text = 0
        TextBox41.Text = ""
        TextBox42.Text = 0
        TextBox43.Text = 0
        TextBox44.Text = 0
        TextBox45.Text = 0

    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click

        Test__DLL_2()

    End Sub
    Private Sub Test__DLL_2()

        TextBox100.Text = 2
        TextBox1.Text = 22
        TextBox2.Text = 21
        TextBox3.Text = 26
        TextBox4.Text = 0
        TextBox5.Text = 31
        TextBox6.Text = 0
        TextBox7.Text = 1
        TextBox8.Text = 0
        TextBox9.Text = 2
        TextBox10.Text = -1

        TextBox12.Text = 1
        TextBox13.Text = 0

        TextBox15.Text = 0
        TextBox16.Text = 35000
        TextBox17.Text = 0
        TextBox18.Text = 0
        TextBox19.Text = 0

        TextBox21.Text = 2.5
        TextBox22.Text = 2.5
        TextBox23.Text = 32
        TextBox24.Text = 0.4
        TextBox25.Text = 18
        TextBox26.Text = 7
        TextBox27.Text = 12
        TextBox28.Text = 0
        TextBox29.Text = 0
        TextBox30.Text = 1000
        TextBox31.Text = 1000
        TextBox32.Text = 0
        TextBox33.Text = 0
        TextBox34.Text = 0


        TextBox38.Text = 0
        TextBox41.Text = ""
        TextBox42.Text = 0
        TextBox43.Text = 0
        TextBox44.Text = 0
        TextBox45.Text = 0

    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click

        Test__DLL_4()

    End Sub
    Private Sub Test__DLL_4()

        TextBox100.Text = 4
        TextBox1.Text = 22
        TextBox2.Text = 21
        TextBox3.Text = 26
        TextBox4.Text = 0
        TextBox5.Text = 31
        TextBox6.Text = 0
        TextBox7.Text = 8
        TextBox8.Text = 5
        TextBox9.Text = 10
        TextBox10.Text = 10

        TextBox12.Text = 1
        TextBox13.Text = 0

        TextBox15.Text = 0
        TextBox16.Text = 30000
        TextBox17.Text = 0
        TextBox18.Text = 0
        TextBox19.Text = 0

        TextBox21.Text = 2.5
        TextBox22.Text = 2.5
        TextBox23.Text = 32
        TextBox24.Text = 0.4
        TextBox25.Text = 20
        TextBox26.Text = 5
        TextBox27.Text = 3
        TextBox28.Text = 50
        TextBox29.Text = 0
        TextBox30.Text = 1000
        TextBox31.Text = 1000
        TextBox32.Text = 0
        TextBox33.Text = 0
        TextBox34.Text = 0


        TextBox38.Text = 0
        TextBox41.Text = ""
        TextBox42.Text = 0
        TextBox43.Text = 0
        TextBox44.Text = 0
        TextBox45.Text = 0

    End Sub

    Private Sub Button5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button5.Click

        Test__DLL_3()

    End Sub
    Private Sub Test__DLL_3()

        TextBox100.Text = 3
        TextBox1.Text = 22
        TextBox2.Text = 21
        TextBox3.Text = 26
        TextBox4.Text = 0
        TextBox5.Text = 31
        TextBox6.Text = 0
        TextBox7.Text = 8
        TextBox8.Text = 45
        TextBox9.Text = 10
        TextBox10.Text = 10

        TextBox12.Text = 1
        TextBox13.Text = 0

        TextBox15.Text = 0
        TextBox16.Text = 60000
        TextBox17.Text = 0
        TextBox18.Text = 0
        TextBox19.Text = 0

        TextBox21.Text = 2.5
        TextBox22.Text = 2.5
        TextBox23.Text = 32
        TextBox24.Text = 0.5
        TextBox25.Text = 40
        TextBox26.Text = 40
        TextBox27.Text = 2
        TextBox28.Text = 0
        TextBox29.Text = 0
        TextBox30.Text = 1000
        TextBox31.Text = 1000
        TextBox32.Text = 0
        TextBox33.Text = 0
        TextBox34.Text = 0


        TextBox38.Text = 0
        TextBox41.Text = ""
        TextBox42.Text = 0
        TextBox43.Text = 0
        TextBox44.Text = 0
        TextBox45.Text = 0

    End Sub

    Private Sub Button11_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button11.Click
        Examples__DLL_1_1()
    End Sub
    Private Sub Examples__DLL_1_1()

        TextBox100.Text = 1
        TextBox1.Text = 22
        TextBox2.Text = 21
        TextBox3.Text = 26
        TextBox4.Text = 0
        TextBox5.Text = 31
        TextBox6.Text = 0
        TextBox7.Text = 1
        TextBox8.Text = 0
        TextBox9.Text = 2
        TextBox10.Text = -1

        TextBox12.Text = 1
        TextBox13.Text = 0

        TextBox15.Text = 0
        TextBox16.Text = 20000
        TextBox17.Text = 0
        TextBox18.Text = 0
        TextBox19.Text = 0

        TextBox21.Text = 2.5
        TextBox22.Text = 2.5
        TextBox23.Text = 0
        TextBox24.Text = 0.5
        TextBox25.Text = 35
        TextBox26.Text = 90
        TextBox27.Text = 70
        TextBox28.Text = 0
        TextBox29.Text = 0
        TextBox30.Text = 1000
        TextBox31.Text = 1000
        TextBox32.Text = 0
        TextBox33.Text = 0
        TextBox34.Text = 0


        TextBox38.Text = 0
        TextBox41.Text = ""
        TextBox42.Text = 0
        TextBox43.Text = 0
        TextBox44.Text = 0
        TextBox45.Text = 0

    End Sub

    Private Sub Button12_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button12.Click
        Examples__DLL_1_2()
    End Sub
    Private Sub Examples__DLL_1_2()

        TextBox100.Text = 1
        TextBox1.Text = 22
        TextBox2.Text = 21
        TextBox3.Text = 26
        TextBox4.Text = 0
        TextBox5.Text = 31
        TextBox6.Text = 0
        TextBox7.Text = 1
        TextBox8.Text = 0
        TextBox9.Text = 2
        TextBox10.Text = -1

        TextBox12.Text = 1
        TextBox13.Text = 0

        TextBox15.Text = 0
        TextBox16.Text = 20000
        TextBox17.Text = 0
        TextBox18.Text = 0
        TextBox19.Text = 0

        TextBox21.Text = 2.5
        TextBox22.Text = 2.5
        TextBox23.Text = 0
        TextBox24.Text = 0.5
        TextBox25.Text = 0
        TextBox26.Text = 90
        TextBox27.Text = 70
        TextBox28.Text = 0
        TextBox29.Text = 150000
        TextBox30.Text = 1000
        TextBox31.Text = 1000
        TextBox32.Text = 0
        TextBox33.Text = 0
        TextBox34.Text = 0


        TextBox38.Text = 0
        TextBox41.Text = ""
        TextBox42.Text = 0
        TextBox43.Text = 0
        TextBox44.Text = 0
        TextBox45.Text = 0

    End Sub

    Private Sub Button13_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button13.Click
        Examples__DLL_1_3()
    End Sub
    Private Sub Examples__DLL_1_3()

        TextBox100.Text = 1
        TextBox1.Text = 22
        TextBox2.Text = 21
        TextBox3.Text = 26
        TextBox4.Text = 0
        TextBox5.Text = 31
        TextBox6.Text = 0
        TextBox7.Text = 1
        TextBox8.Text = 0
        TextBox9.Text = 2
        TextBox10.Text = -1

        TextBox12.Text = 3
        TextBox13.Text = 0

        TextBox15.Text = 0
        TextBox16.Text = 20000
        TextBox17.Text = 0
        TextBox18.Text = 0
        TextBox19.Text = 0

        TextBox21.Text = 2.5
        TextBox22.Text = 2.5
        TextBox23.Text = 0
        TextBox24.Text = 0.5
        TextBox25.Text = 0
        TextBox26.Text = 90
        TextBox27.Text = 70
        TextBox28.Text = 0
        TextBox29.Text = 0
        TextBox30.Text = 1000
        TextBox31.Text = 1000
        TextBox32.Text = 3
        TextBox33.Text = 20
        TextBox34.Text = 0


        TextBox38.Text = 0
        TextBox41.Text = ""
        TextBox42.Text = 0
        TextBox43.Text = 0
        TextBox44.Text = 0
        TextBox45.Text = 0

    End Sub

    Private Sub Button14_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button14.Click
        Examples__DLL_1_4()
    End Sub
    Private Sub Examples__DLL_1_4()

        TextBox100.Text = 1
        TextBox1.Text = 22
        TextBox2.Text = 21
        TextBox3.Text = 26
        TextBox4.Text = 0
        TextBox5.Text = 31
        TextBox6.Text = 0
        TextBox7.Text = 1
        TextBox8.Text = 0
        TextBox9.Text = 2
        TextBox10.Text = -1

        TextBox12.Text = 3
        TextBox13.Text = 0

        TextBox15.Text = 0
        TextBox16.Text = 20000
        TextBox17.Text = 0
        TextBox18.Text = 0
        TextBox19.Text = 0

        TextBox21.Text = 2.5
        TextBox22.Text = 2.5
        TextBox23.Text = 0
        TextBox24.Text = 0.5
        TextBox25.Text = 0
        TextBox26.Text = 90
        TextBox27.Text = 0
        TextBox28.Text = 0.00105
        TextBox29.Text = 0
        TextBox30.Text = 1000
        TextBox31.Text = 1000
        TextBox32.Text = 3
        TextBox33.Text = 20
        TextBox34.Text = 0


        TextBox38.Text = 0
        TextBox41.Text = ""
        TextBox42.Text = 0
        TextBox43.Text = 0
        TextBox44.Text = 0
        TextBox45.Text = 0

    End Sub


    Private Sub Button15_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button15.Click
        Examples__DLL_2_1()
    End Sub
    Private Sub Examples__DLL_2_1()

        TextBox100.Text = 2
        TextBox1.Text = 22
        TextBox2.Text = 21
        TextBox3.Text = 26
        TextBox4.Text = 0
        TextBox5.Text = 31
        TextBox6.Text = 0
        TextBox7.Text = 1
        TextBox8.Text = 0
        TextBox9.Text = 2
        TextBox10.Text = -1

        TextBox12.Text = 1
        TextBox13.Text = 0

        TextBox15.Text = 0
        TextBox16.Text = 35000
        TextBox17.Text = 0
        TextBox18.Text = 0
        TextBox19.Text = 0

        TextBox21.Text = 2.5
        TextBox22.Text = 2.5
        TextBox23.Text = 32
        TextBox24.Text = 0.4
        TextBox25.Text = 18
        TextBox26.Text = 7
        TextBox27.Text = 12
        TextBox28.Text = 0
        TextBox29.Text = 0
        TextBox30.Text = 1000
        TextBox31.Text = 1000
        TextBox32.Text = 0
        TextBox33.Text = 0
        TextBox34.Text = 0


        TextBox38.Text = 0
        TextBox41.Text = ""
        TextBox42.Text = 0
        TextBox43.Text = 0
        TextBox44.Text = 0
        TextBox45.Text = 0

    End Sub


    Private Sub Button16_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button16.Click
        Examples__DLL_4_1()
    End Sub
    Private Sub Examples__DLL_4_1()

        TextBox100.Text = 4
        TextBox1.Text = 22
        TextBox2.Text = 21
        TextBox3.Text = 26
        TextBox4.Text = 0
        TextBox5.Text = 31
        TextBox6.Text = 0
        TextBox7.Text = 8
        TextBox8.Text = 5
        TextBox9.Text = 10
        TextBox10.Text = 10
        TextBox12.Text = 1
        TextBox13.Text = 0
        TextBox15.Text = 0
        TextBox16.Text = 30000
        TextBox17.Text = 0
        TextBox18.Text = 0
        TextBox19.Text = 0
        TextBox21.Text = 2.5
        TextBox22.Text = 2.5
        TextBox23.Text = 32
        TextBox24.Text = 0.4
        TextBox25.Text = 20
        TextBox26.Text = 5
        TextBox27.Text = 3
        TextBox28.Text = 50
        TextBox29.Text = 0
        TextBox30.Text = 1000
        TextBox31.Text = 1000
        TextBox32.Text = 0
        TextBox33.Text = 0
        TextBox34.Text = 0


        TextBox38.Text = 0
        TextBox41.Text = ""
        TextBox42.Text = 0
        TextBox43.Text = 0
        TextBox44.Text = 0
        TextBox45.Text = 0

    End Sub

    Private Sub Button17_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button17.Click
        Examples__DLL_4_2()
    End Sub
    Private Sub Examples__DLL_4_2()

        TextBox100.Text = 4
        TextBox1.Text = 22
        TextBox2.Text = 21
        TextBox3.Text = 26
        TextBox4.Text = 0
        TextBox5.Text = 31
        TextBox6.Text = 0
        TextBox7.Text = 8
        TextBox8.Text = 5
        TextBox9.Text = 10
        TextBox10.Text = 10

        TextBox12.Text = 1
        TextBox13.Text = 0

        TextBox15.Text = 0
        TextBox16.Text = 30000
        TextBox17.Text = 0
        TextBox18.Text = 0
        TextBox19.Text = 0

        TextBox21.Text = 2.5
        TextBox22.Text = 2.5
        TextBox23.Text = 32
        TextBox24.Text = 0.4
        TextBox25.Text = 0
        TextBox26.Text = 5
        TextBox27.Text = 3
        TextBox28.Text = 50
        TextBox29.Text = 50000
        TextBox30.Text = 1000
        TextBox31.Text = 1000
        TextBox32.Text = 0
        TextBox33.Text = 0
        TextBox34.Text = 0


        TextBox38.Text = 0
        TextBox41.Text = ""
        TextBox42.Text = 0
        TextBox43.Text = 0
        TextBox44.Text = 0
        TextBox45.Text = 0

    End Sub

    Private Sub Button18_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button18.Click
        Examples__DLL_4_3()
    End Sub
    Private Sub Examples__DLL_4_3()

        TextBox100.Text = 4
        TextBox1.Text = 22
        TextBox2.Text = 21
        TextBox3.Text = 26
        TextBox4.Text = 0
        TextBox5.Text = 31
        TextBox6.Text = 0
        TextBox7.Text = 8
        TextBox8.Text = 5
        TextBox9.Text = 10
        TextBox10.Text = 10
        TextBox12.Text = 3
        TextBox13.Text = 0
        TextBox15.Text = 0
        TextBox16.Text = 30000
        TextBox17.Text = 0
        TextBox18.Text = 0
        TextBox19.Text = 0
        TextBox21.Text = 2.5
        TextBox22.Text = 2.5
        TextBox23.Text = 32
        TextBox24.Text = 0.4
        TextBox25.Text = 0
        TextBox26.Text = 5
        TextBox27.Text = 3
        TextBox28.Text = 50
        TextBox29.Text = 0
        TextBox30.Text = 1000
        TextBox31.Text = 1000
        TextBox32.Text = 3
        TextBox33.Text = 30
        TextBox34.Text = 0


        TextBox38.Text = 0
        TextBox41.Text = ""
        TextBox42.Text = 0
        TextBox43.Text = 0
        TextBox44.Text = 0
        TextBox45.Text = 0

    End Sub

    Private Sub Button19_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button19.Click
        Examples__DLL_3_1()
    End Sub
    Private Sub Examples__DLL_3_1()

        TextBox100.Text = 3
        TextBox1.Text = 22
        TextBox2.Text = 21
        TextBox3.Text = 26
        TextBox4.Text = 0
        TextBox5.Text = 31
        TextBox6.Text = 0
        TextBox7.Text = 8
        TextBox8.Text = 45
        TextBox9.Text = 10
        TextBox10.Text = 10
        TextBox12.Text = 1
        TextBox13.Text = 0
        TextBox15.Text = 0
        TextBox16.Text = 60000
        TextBox17.Text = 0
        TextBox18.Text = 0
        TextBox19.Text = 0
        TextBox21.Text = 2.5
        TextBox22.Text = 2.5
        TextBox23.Text = 32
        TextBox24.Text = 0.5
        TextBox25.Text = 40
        TextBox26.Text = 30
        TextBox27.Text = 2
        TextBox28.Text = 0
        TextBox29.Text = 0
        TextBox30.Text = 1000
        TextBox31.Text = 1000
        TextBox32.Text = 0
        TextBox33.Text = 0
        TextBox34.Text = 0


        TextBox38.Text = 0
        TextBox41.Text = ""
        TextBox42.Text = 0
        TextBox43.Text = 0
        TextBox44.Text = 0
        TextBox45.Text = 0

    End Sub

    Private Sub Button20_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button20.Click
        Examples__DLL_3_2()
    End Sub
    Private Sub Examples__DLL_3_2()

        TextBox100.Text = 3
        TextBox1.Text = 22
        TextBox2.Text = 21
        TextBox3.Text = 26
        TextBox4.Text = 0
        TextBox5.Text = 31
        TextBox6.Text = 0
        TextBox7.Text = 8
        TextBox8.Text = 45
        TextBox9.Text = 10
        TextBox10.Text = 10
        TextBox12.Text = 1
        TextBox13.Text = 0
        TextBox15.Text = 0
        TextBox16.Text = 60000
        TextBox17.Text = 0
        TextBox18.Text = 0
        TextBox19.Text = 0
        TextBox21.Text = 2.5
        TextBox22.Text = 2.5
        TextBox23.Text = 32
        TextBox24.Text = 0.5
        TextBox25.Text = 0
        TextBox26.Text = 30
        TextBox27.Text = 2
        TextBox28.Text = 0
        TextBox29.Text = 33000
        TextBox30.Text = 1000
        TextBox31.Text = 1000
        TextBox32.Text = 0
        TextBox33.Text = 0
        TextBox34.Text = 0


        TextBox38.Text = 0
        TextBox41.Text = ""
        TextBox42.Text = 0
        TextBox43.Text = 0
        TextBox44.Text = 0
        TextBox45.Text = 0

    End Sub

    Private Sub Button21_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button21.Click
        Examples__DLL_3_3()
    End Sub
    Private Sub Examples__DLL_3_3()

        TextBox100.Text = 3
        TextBox1.Text = 22
        TextBox2.Text = 21
        TextBox3.Text = 26
        TextBox4.Text = 0
        TextBox5.Text = 31
        TextBox6.Text = 0
        TextBox7.Text = 8
        TextBox8.Text = 45
        TextBox9.Text = 10
        TextBox10.Text = 10
        TextBox12.Text = 3
        TextBox13.Text = 0
        TextBox15.Text = 0
        TextBox16.Text = 60000
        TextBox17.Text = 0
        TextBox18.Text = 0
        TextBox19.Text = 0
        TextBox21.Text = 2.5
        TextBox22.Text = 2.5
        TextBox23.Text = 32
        TextBox24.Text = 0.5
        TextBox25.Text = 0
        TextBox26.Text = 30
        TextBox27.Text = 2
        TextBox28.Text = 0
        TextBox29.Text = 0
        TextBox30.Text = 1000
        TextBox31.Text = 1000
        TextBox32.Text = 4
        TextBox33.Text = 7
        TextBox34.Text = 0


        TextBox38.Text = 0
        TextBox41.Text = ""
        TextBox42.Text = 0
        TextBox43.Text = 0
        TextBox44.Text = 0
        TextBox45.Text = 0

    End Sub

    Private Sub Button22_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button22.Click
        Examples__DLL_1()
    End Sub
    Private Sub Examples__DLL_1()

        TextBox100.Text = 1
        TextBox1.Text = 25
        TextBox2.Text = 22
        TextBox3.Text = 29
        TextBox4.Text = 0
        TextBox5.Text = 33
        TextBox6.Text = 1
        TextBox7.Text = 1
        TextBox8.Text = 0
        TextBox9.Text = 2
        TextBox10.Text = -1
        TextBox12.Text = 3
        TextBox13.Text = 0
        TextBox15.Text = 0
        TextBox16.Text = 20000
        TextBox17.Text = 0
        TextBox18.Text = 0
        TextBox19.Text = 0
        TextBox21.Text = 2.16027777777778
        TextBox22.Text = 2.5
        TextBox23.Text = 0
        TextBox24.Text = 0.5
        TextBox25.Text = 0
        TextBox26.Text = 90
        TextBox27.Text = 0
        TextBox28.Text = 0.002
        TextBox29.Text = 0
        TextBox30.Text = 1000
        TextBox31.Text = 980
        TextBox32.Text = 3
        TextBox33.Text = 11
        TextBox34.Text = 2


        TextBox38.Text = 0
        TextBox41.Text = ""
        TextBox42.Text = 0
        TextBox43.Text = 0
        TextBox44.Text = 0
        TextBox45.Text = 0

    End Sub

    Private Sub Button23_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button23.Click
        Examples__DLL_2()
    End Sub
    Private Sub Examples__DLL_2()

        TextBox100.Text = 1
        TextBox1.Text = 22
        TextBox2.Text = 21
        TextBox3.Text = 26
        TextBox4.Text = 0
        TextBox5.Text = 31
        TextBox6.Text = 0
        TextBox7.Text = 2
        TextBox8.Text = 33
        TextBox9.Text = 2
        TextBox10.Text = 8
        TextBox12.Text = 3
        TextBox13.Text = 6
        TextBox15.Text = 0
        TextBox16.Text = 20000
        TextBox17.Text = 666
        TextBox18.Text = 0.0007
        TextBox19.Text = 0.23
        TextBox21.Text = 2.5
        TextBox22.Text = 2.5
        TextBox23.Text = 0
        TextBox24.Text = 0.5
        TextBox25.Text = 0
        TextBox26.Text = 90
        TextBox27.Text = 70
        TextBox28.Text = 0
        TextBox29.Text = 0
        TextBox30.Text = 1000
        TextBox31.Text = 1000
        TextBox32.Text = 3
        TextBox33.Text = 11
        TextBox34.Text = 0


        TextBox41.Text = ""
        TextBox42.Text = 0
        TextBox43.Text = 0
        TextBox44.Text = 0
        TextBox45.Text = 0

        'PRESS CLEAR AFTER THE CALCULATION!!!
        TextBox38.Text = 2
        'PRESS CLEAR AFTER THE CALCULATION!!!

    End Sub

    Private Sub Button24_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button24.Click
        Examples__DLL_3()
    End Sub
    Private Sub Examples__DLL_3()

        TextBox100.Text = 1
        TextBox1.Text = 22
        TextBox2.Text = 21
        TextBox3.Text = 26
        TextBox4.Text = 0
        TextBox5.Text = 31
        TextBox6.Text = 0
        TextBox7.Text = 1
        TextBox8.Text = 0
        TextBox9.Text = 2
        TextBox10.Text = -1
        TextBox12.Text = 3
        TextBox13.Text = 0
        TextBox15.Text = 0
        TextBox16.Text = 20000
        TextBox17.Text = 0
        TextBox18.Text = 0
        TextBox19.Text = 0
        TextBox21.Text = 2.5
        TextBox22.Text = 2.5
        TextBox23.Text = 0
        TextBox24.Text = 0.5
        TextBox25.Text = 35
        TextBox26.Text = 90
        TextBox27.Text = 70
        TextBox28.Text = 0
        TextBox29.Text = 0
        TextBox30.Text = 1000
        TextBox31.Text = 1000
        TextBox32.Text = 0
        TextBox33.Text = 17
        TextBox34.Text = 0


        TextBox38.Text = 0
        TextBox41.Text = ""
        TextBox42.Text = 0
        TextBox43.Text = 0
        TextBox44.Text = 0
        TextBox45.Text = 0

    End Sub

    Private Sub Button25_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button25.Click
        Examples__DLL_4()
    End Sub
    Private Sub Examples__DLL_4()

        TextBox100.Text = 2
        TextBox1.Text = 22
        TextBox2.Text = 21
        TextBox3.Text = 26
        TextBox4.Text = 0
        TextBox5.Text = 31
        TextBox6.Text = 0
        TextBox7.Text = 8
        TextBox8.Text = 4
        TextBox9.Text = 2
        TextBox10.Text = -1
        TextBox12.Text = 1
        TextBox13.Text = 0
        TextBox15.Text = 0
        TextBox16.Text = 17000
        TextBox17.Text = 0
        TextBox18.Text = 0
        TextBox19.Text = 0
        TextBox21.Text = 2.5
        TextBox22.Text = 2.5
        TextBox23.Text = 20
        TextBox24.Text = 0.4
        TextBox25.Text = -11
        TextBox26.Text = -20
        TextBox27.Text = -10
        TextBox28.Text = 0
        TextBox29.Text = 0
        TextBox30.Text = 1000
        TextBox31.Text = 1000
        TextBox32.Text = 0
        TextBox33.Text = 0
        TextBox34.Text = 0


        TextBox38.Text = 0
        TextBox41.Text = ""
        TextBox42.Text = 0
        TextBox43.Text = 0
        TextBox44.Text = 0
        TextBox45.Text = 0

    End Sub

    Private Sub Button26_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button26.Click
        Examples__DLL_5()
    End Sub
    Private Sub Examples__DLL_5()

        TextBox100.Text = 4
        TextBox1.Text = 22
        TextBox2.Text = 21
        TextBox3.Text = 26
        TextBox4.Text = 0
        TextBox5.Text = 31
        TextBox6.Text = 0
        TextBox7.Text = 4
        TextBox8.Text = 5
        TextBox9.Text = 10
        TextBox10.Text = 10
        TextBox12.Text = 1
        TextBox13.Text = 0
        TextBox15.Text = 0
        TextBox16.Text = 30000
        TextBox17.Text = 0
        TextBox18.Text = 0
        TextBox19.Text = 0
        TextBox21.Text = 2.5
        TextBox22.Text = 2.5
        TextBox23.Text = 32
        TextBox24.Text = 0.85
        TextBox25.Text = 20
        TextBox26.Text = 7
        TextBox27.Text = 4
        TextBox28.Text = 55
        TextBox29.Text = 0
        TextBox30.Text = 1000
        TextBox31.Text = 1000
        TextBox32.Text = 0
        TextBox33.Text = 0
        TextBox34.Text = 0


        TextBox38.Text = 0
        TextBox41.Text = ""
        TextBox42.Text = 0
        TextBox43.Text = 0
        TextBox44.Text = 0
        TextBox45.Text = 0

    End Sub

    Private Sub Button27_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button27.Click
        Examples__DLL_6()
    End Sub
    Private Sub Examples__DLL_6()

        TextBox100.Text = 3
        TextBox1.Text = 22
        TextBox2.Text = 21
        TextBox3.Text = 26
        TextBox4.Text = 0
        TextBox5.Text = 31
        TextBox6.Text = 0
        TextBox7.Text = 9
        TextBox8.Text = 45
        TextBox9.Text = 4
        TextBox10.Text = 1
        TextBox12.Text = 1
        TextBox13.Text = 0
        TextBox15.Text = 0
        TextBox16.Text = 60000
        TextBox17.Text = 0
        TextBox18.Text = 0
        TextBox19.Text = 0
        TextBox21.Text = 2.5
        TextBox22.Text = 2.5
        TextBox23.Text = 32
        TextBox24.Text = 0.5
        TextBox25.Text = 40
        TextBox26.Text = 44
        TextBox27.Text = 1
        TextBox28.Text = 0
        TextBox29.Text = 0
        TextBox30.Text = 1000
        TextBox31.Text = 1000
        TextBox32.Text = 0
        TextBox33.Text = 0
        TextBox34.Text = 0


        TextBox38.Text = 0
        TextBox41.Text = ""
        TextBox42.Text = 0
        TextBox43.Text = 0
        TextBox44.Text = 0
        TextBox45.Text = 0

    End Sub

    Private Sub Button28_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button28.Click
        Examples__DLL_7()
    End Sub
    Private Sub Examples__DLL_7()

        TextBox100.Text = 2
        TextBox1.Text = 22
        TextBox2.Text = 21
        TextBox3.Text = 26
        TextBox4.Text = 0
        TextBox5.Text = 31
        TextBox6.Text = 0
        TextBox7.Text = 10
        TextBox8.Text = 0
        TextBox9.Text = 2
        TextBox10.Text = -1

        TextBox12.Text = 3
        TextBox13.Text = 0

        TextBox15.Text = 0
        TextBox16.Text = 35000
        TextBox17.Text = 0
        TextBox18.Text = 0
        TextBox19.Text = 0

        TextBox21.Text = 2.5
        TextBox22.Text = 2.5
        TextBox23.Text = 32
        TextBox24.Text = 0.4
        TextBox25.Text = 0
        TextBox26.Text = 7
        TextBox27.Text = 12
        TextBox28.Text = 0
        TextBox29.Text = 0
        TextBox30.Text = 1000
        TextBox31.Text = 1000
        TextBox32.Text = 4
        TextBox33.Text = 32
        TextBox34.Text = 0


        TextBox38.Text = 0


        'PRESS CLEAR AFTER THE CALCULATION!!!
        TextBox41.Text = "MyFluid"
        TextBox42.Text = 4000
        TextBox43.Text = 1000
        TextBox44.Text = 0.0003
        TextBox45.Text = 0.7
        'PRESS CLEAR AFTER THE CALCULATION!!!

    End Sub

End Class

